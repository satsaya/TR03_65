from unicodedata import name
from search_in_db import  *
import pandas as pd
import os 
full_path = os.path.realpath(__file__)
full_dir = os.path.dirname(full_path)
data_path = 'data'
myFileName= os.path.join(full_dir,data_path,'data.xlsx')
type_db = ['ประเภทย่อย-อ-']
typeall = []
year_ = ['ปีทั้งหมด']
year_all = []
room_db = []
namet_ = ['ประเภททั้งหมด']

status1_dp_all = ["ส.พัสดุปัจจุบัน","รายการขอโอน","รายการรับโอน","รายการขอยุบสภาพ","รายการจำหน่ายแล้ว","รายการจัดสรร"]
status1_dp = ["ส.พัสดุปัจจุบัน"]
status2_dp_all = ["ส.ความรับผิดชอบ","ในความรับผิดชอบ","นอกความรับผิดชอบ"]
status2_dp = ["ส.ความรับผิดชอบ"]
status3_dp_all = ["ส.ใช้งานปัจจุบัน","ปกติ","ชำรุด/ซ่อมได้","ชำรุด/ซ่อมไม่ได้"]
status3_dp = ["ส.ใช้งานปัจจุบัน"]
status4_dp_all = ["ส.บำรุงรักษาล่าสุด","แก้ไขได้/ใช้งานได้","แก้ไขไม่ได้/ใช้งานไม่ได้","แก้ไขไม่ได้/ใช้งานได้"]
status4_dp = ["ส.บำรุงรักษาล่าสุด"]
status5_dp_all = ["ส.ตรวจสภาพ","ปกติ","ปกติ/แต่ไม่ได้ใช้งานแล้ว","ไม่สมบูรณ์","ชำรุด/ซ่อมได้ ควรส่งซ่อม","ชำรุด/ซ่อมไม่ได้ ควรขอยุบสภาพ"]
status5_dp = ["ส.ตรวจสภาพ"]
subtype_thai_dp = ["ประเภททั้งหมด"]
subsubtype_db = ["ประเภทย่อย-ท-"]
namer_db=[]
owner_db = []
#id roon place
id_room_p_db = []
#level4 place
level4_p_db = []
level4_name_p_db = []
#level3 place
level3_p_db = []
level3_name_p_db = []
#level2 place
level2_p_db = []
level2_name_p_db = []
#level1 place
level1_p_db = []
level1_name_p_db = []
#owner table
font_name_db = []
name_owner_db = []
post_db = []
olevel_db = []
oroom_db = []
oroom_name_db = []
otel_db = []
olevel1_db = []
olevel1_name_db = []
olevel2_db = []
olevel2_name_db = []
olevel3_db = []
olevel3_name_db = []
olevel4_db = []
olevel4_name_db = []
wrooom_db = []
wrooom_name_db = []
wtel_db = []
wlevel1_db = []
wlevel1_name_db = []
wlevel2_db = []
wlevel2_name_db = []
wlevel3_db = []
wlevel3_name_db = []
wlevel4_db = []
wlevel4_name_db = []
#owner table
def all_wlevel1():
        tem = search_in_db()
        rows = tem.get_wlevel1_ow()
        for i in rows:
                wlevel1_db.append(str(i[0]))
        return rows
all_wlevel1()
def all_wlevel1_name():
        tem = search_in_db()
        rows = tem.get_wlevel1_name_ow()
        for i in rows:
                wlevel1_name_db.append(str(i[0]))
        return rows
all_wlevel1_name()
def all_wlevel2():
        tem = search_in_db()
        rows = tem.get_wlevel2_ow()
        for i in rows:
                wlevel2_db.append(str(i[0]))
        return rows
all_wlevel2()
def all_wlevel2_name():
        tem = search_in_db()
        rows = tem.get_wlevel2_name_ow()
        for i in rows:
                wlevel2_name_db.append(str(i[0]))
        return rows
all_wlevel2_name()
def all_wlevel3():
        tem = search_in_db()
        rows = tem.get_wlevel3_ow()
        for i in rows:
                wlevel3_db.append(str(i[0]))
        return rows
all_wlevel3()
def all_wlevel3_name():
        tem = search_in_db()
        rows = tem.get_wlevel3_name_ow()
        for i in rows:
                wlevel3_name_db.append(str(i[0]))
        return rows
all_wlevel3_name()
def all_wlevel4():
        tem = search_in_db()
        rows = tem.get_wlevel4_ow()
        for i in rows:
                wlevel4_db.append(str(i[0]))
        return rows
all_wlevel4()
def all_wlevel4_name():
        tem = search_in_db()
        rows = tem.get_wlevel4_name_ow()
        for i in rows:
                wlevel4_name_db.append(str(i[0]))
        return rows
all_wlevel4_name()
def all_wrooom():
        tem = search_in_db()
        rows = tem.get_wrooom_ow()
        for i in rows:
                wrooom_db.append(str(i[0]))
        return rows
all_wrooom()
def all_name_owner():
        tem = search_in_db()
        rows = tem.get_name_all_ow()
        for i in rows:
                name_owner_db.append(str(i[0]))
        return rows
all_name_owner()
###################
def all_olevel1():
        tem = search_in_db()
        rows = tem.get_olevel1_ow()
        for i in rows:
                olevel1_db.append(str(i[0]))
        return rows
all_olevel1()
def all_olevel1_name():
        tem = search_in_db()
        rows = tem.get_olevel1_name_ow()
        for i in rows:
                olevel1_name_db.append(str(i[0]))
        return rows
all_olevel1_name()
def all_olevel2():
        tem = search_in_db()
        rows = tem.get_olevel2_ow()
        for i in rows:
                olevel2_db.append(str(i[0]))
        return rows
all_olevel2()
def all_olevel2_name():
        tem = search_in_db()
        rows = tem.get_olevel2_name_ow()
        for i in rows:
                olevel2_name_db.append(str(i[0]))
        return rows
all_olevel2_name()
def all_olevel3():
        tem = search_in_db()
        rows = tem.get_olevel3_ow()
        for i in rows:
                olevel3_db.append(str(i[0]))
        return rows
all_olevel3()
def all_olevel3_name():
        tem = search_in_db()
        rows = tem.get_olevel3_name_ow()
        for i in rows:
                olevel3_name_db.append(str(i[0]))
        return rows
all_olevel3_name()
def all_olevel4():
        tem = search_in_db()
        rows = tem.get_olevel4_ow()
        for i in rows:
                olevel4_db.append(str(i[0]))
        return rows
all_olevel4()
def all_olevel4_name():
        tem = search_in_db()
        rows = tem.get_olevel4_name_ow()
        for i in rows:
                olevel4_name_db.append(str(i[0]))
        return rows
all_olevel4_name()
def all_oroom():
        tem = search_in_db()
        rows = tem.get_oroom_ow()
        for i in rows:
                oroom_db.append(str(i[0]))
        return rows
all_oroom()
def all_olevel():
        tem = search_in_db()
        rows = tem.get_olevel_ow()
        for i in rows:
                olevel_db.append(str(i[0]))
        return rows
all_olevel()
def all_font_name():
        tem = search_in_db()
        rows = tem.get_font_name_ow()
        for i in rows:
                font_name_db.append(str(i[0]))
        return rows
all_font_name()
def all_post():
        tem = search_in_db()
        rows = tem.get_post_ow()
        for i in rows:
                post_db.append(str(i[0]))
        return rows
all_post()
#id room place
def all_id_room_p():
        tem = search_in_db()
        rows = tem.get_id_room_p()
        for i in rows:
                id_room_p_db.append(str(i[0]))
        return rows
all_id_room_p()
#level1 place
def all_level1_p():
        tem = search_in_db()
        rows = tem.get_level1_p()
        for i in rows:
                level1_p_db.append(str(i[0]))
        return rows
all_level1_p()
def all_level1_name_p():
        tem = search_in_db()
        rows = tem.get_level1_name_p()
        for i in rows:
                level1_name_p_db.append(str(i[0]))
        return rows
all_level1_name_p()
#level2 place
def all_level2_p():
        tem = search_in_db()
        rows = tem.get_level2_p()
        for i in rows:
                level2_p_db.append(str(i[0]))
        return rows
all_level2_p()
def all_level2_name_p():
        tem = search_in_db()
        rows = tem.get_level2_name_p()
        for i in rows:
                level2_name_p_db.append(str(i[0]))
        return rows
all_level2_name_p()
#level4 place
def all_level4_p():
        tem = search_in_db()
        rows = tem.get_level4_p()
        for i in rows:
                level4_p_db.append(str(i[0]))
        return rows
all_level4_p()
def all_level4_name_p():
        tem = search_in_db()
        rows = tem.get_level4_name_p()
        for i in rows:
                level4_name_p_db.append(str(i[0]))
        return rows
all_level4_name_p()
#level3 place
def all_level3_p():
        tem = search_in_db()
        rows = tem.get_level3_p()
        for i in rows:
                level3_p_db.append(str(i[0]))
        return rows
all_level3_p()
def all_level3_name_p():
        tem = search_in_db()
        rows = tem.get_level3_name_p()
        for i in rows:
                level3_name_p_db.append(str(i[0]))
        return rows
all_level3_name_p()
########################
def all_owner():
        tem = search_in_db()
        rows = tem.get_owner()
        for i in rows:
                owner_db.append(str(i[0]))
        return rows
all_owner()
def all_namer():
        tem = search_in_db()
        rows = tem.get_namer()
        for i in rows:
                namer_db.append(str(i[0]))
        return rows
all_namer()
def all_room():
        tem = search_in_db()
        rows = tem.get_room()
        for i in rows:
                room_db.append(str(i[0]))
        return rows
all_room()
def all_subsubtype():
        tem = search_in_db()
        rows = tem.get_subsubtype()
        for i in rows:
                subsubtype_db.append(str(i[0]))
        return rows
all_subsubtype()
def all_subtype_thai():
        tem = search_in_db()
        rows = tem.get_subtype_thai()
        for i in rows:
                subtype_thai_dp.append(str(i[0]))
        return rows
all_subtype_thai()
def all_year():
        tem = search_in_db()
        rows = tem.get_year_db()
        # df = pd.read_excel(myFileName, sheet_name=0)
        # x = df['ปีทั้งหมด'].tolist()
        for i in rows:
                year_.append(i[0])
                year_all.append(i[0])

all_year()

def all_type():
        tem = search_in_db()
        rows = tem.get_type_db()
        for i in rows:
                type_db.append(str(i[0]))
                typeall.append(str(i[0]))
        return rows
all_type()

def all_namet():
        tem = search_in_db()
        rows = tem.get_namet()
        for i in rows:
                namet_.append(str(i[0]))
        return rows
all_namet()

def all_status3():
        tem = search_in_db()
        rows = tem.get_status3()
        for i in rows:
                status3_dp.append(i)
        return rows
all_status3()

def all_status1():
        tem = search_in_db()
        rows = tem.get_status1()
        for i in rows:
                status1_dp.append(i)
        return rows
all_status1()

def rifferenc_number():
        df = pd.read_excel(myFileName, sheet_name=1)
        x = df['หมายเลขอ้างอิง'].tolist()
        return x
rifferenc_number()

def all_status2():
        temp = search_in_db()
        rows = temp.get_status2()
        for i in rows:
                status2_dp.append(i)
        return rows
all_status2()

# type_= ['ประเภททั้งหมด','AP','APO','Appliance','Cabinet','Camera',
#         'Chair','General','Monitor',
#         'Notebook','PC','Printer','Progarm','Projector'
#         ,'Rack','Reader','Scanner','Server','Sound System','Storage'
#         ,'Switch'
#         ,'Table','Tablet','TV','UPS'
#         ]
# year_ = ["ปีทั้งหมด",'43','44','45',
#         '46','47','48',
#         '49','50','51',
#         '52','53','54',
#         '55','56','57',
#         '58','59','60',
#         '61','62','63',
#         '64']
# year_for_col = ['43','43','44','44','45','45','46',
#         '46','47','47','48','48','49',
#         '49','50','50','51','51',
#         '52','52','53','53','54','54','55','55','56','56','57',
#         '57','58','58','59','59','60',
#         '60','61','61','62','62',
#         '63','63','64','64'
# ]