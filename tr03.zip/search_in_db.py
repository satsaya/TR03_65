import mysql.connector
import queue
class search_in_db():
    def one(self):
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        sql = "SELECT * FROM item WHERE 1 ORDER BY year"
        
        c = conn.cursor()
        c.execute(sql)
        records = c.fetchall()
        conn.commit()
        conn.close()
        return records
    def show_owner(self):
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        sql = "SELECT * FROM owner WHERE 1 ORDER BY oroom"
        
        c = conn.cursor()
        c.execute(sql)
        records = c.fetchall()
        conn.commit()
        conn.close()
        return records
    def show_place(self):
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        sql = "SELECT * FROM place WHERE 1 ORDER BY id"
        c = conn.cursor()
        c.execute(sql)
        records = c.fetchall()
        conn.commit()
        conn.close()
        return records
    def show_history(self):
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        sql = "SELECT * FROM history_item WHERE 1 ORDER BY id"
        c = conn.cursor()
        c.execute(sql)
        records = c.fetchall()
        conn.commit()
        conn.close()
        return records
    def show_destroy(self):
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        sql = "SELECT * FROM item2 WHERE 1 ORDER BY id"
        c = conn.cursor()
        c.execute(sql)
        records = c.fetchall()
        conn.commit()
        conn.close()
        return records
    def two(self,status,year,type):
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        if status == "ส.ใช้งานปัจจุบัน" and year!="ปีทั้งหมด" and type!="ประเภททั้งหมด" :
            sql = "select * from item where year='"+ year +"'and namet='"+type+"' ORDER BY year"
        elif type=="ประเภททั้งหมด" and status != "ส.ใช้งานปัจจุบัน" and year!="ปีทั้งหมด":
            sql = "select * from item where status3='"+ status +"'and year='"+year+"' ORDER BY year"
        elif year=="ปีทั้งหมด" and status != "ส.ใช้งานปัจจุบัน" and type!="ประเภททั้งหมด":
            sql = "select * from item where status3='"+ status +"'and namet='"+type+"' ORDER BY year"
        elif type=="ประเภททั้งหมด" and status == "ส.ใช้งานปัจจุบัน":
            sql = "select * from item where year='"+ year +"' ORDER BY year"
        elif year=="ปีทั้งหมด" and  status=="ส.ใช้งานปัจจุบัน":
            sql = "select * from item where namet='"+ type +"' ORDER BY year"
        elif type=="ประเภททั้งหมด" and year=="ปีทั้งหมด":
            sql = "select * from item where status3='"+ status +"' ORDER BY year"
        else:
            sql = "select * from item where status3='"+ status +"'and namet='"+type+"'and year='"+year+"' ORDER BY year"
        c = conn.cursor()
        c.execute(sql)
        records = c.fetchall()
        conn.commit()
        conn.close()
        return records
    def three(self,val):
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        c = conn.cursor()
        sql='SELECT * FROM item WHERE id LIKE %s ORDER BY year'
        args=[val+'%']
        c.execute(sql,args)
        records = c.fetchall()
        conn.commit()
        conn.close()
        return records
    def three_(self,val):
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        c = conn.cursor()
        sql='SELECT * FROM history_item WHERE id LIKE %s ORDER BY time'
        args=[val+'%']
        c.execute(sql,args)
        records = c.fetchall()
        conn.commit()
        conn.close()
        return records
    def get_db(self,id):
        if(id==""):
            return
        else:
            mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("select * from item where id='"+ id +"'")
        rows = mycursor.fetchall()
        return rows
    #get_db_place
    def get_db_place(self,id):
        if(id==""):
            return
        else:
            mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("select * from place where id='"+ id +"'")
        rows = mycursor.fetchall()
        return rows

    def get_db_owner(self,name):
        if(name==""):
            return
        else:
            mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("select * from owner where name='"+ name +"'")
        rows = mycursor.fetchall()
        return rows

    def get_namer(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT namer FROM item ORDER by namer;")
        rows = mycursor.fetchall()
        return rows
    def get_room(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT place FROM item ORDER by place;")
        rows = mycursor.fetchall()
        return rows
    def get_year_db(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT year FROM item ORDER by year;")
        rows = mycursor.fetchall()
        return rows
    def get_type_db(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT type FROM item ORDER by type;")
        rows = mycursor.fetchall()
        return rows
    def get_status2(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT status2 FROM item ORDER by status2;")
        rows = mycursor.fetchall()
        return rows 
    def get_status3(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT status3 FROM item ORDER by status3;")
        rows = mycursor.fetchall()
        return rows
    def get_owner(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT owner FROM item ORDER by owner;")
        rows = mycursor.fetchall()
        return rows
    def get_level1_p(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT level1 FROM place ORDER by level1;")
        rows = mycursor.fetchall()
        return rows

    #id_room_place
    def get_id_room_p(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT id FROM place ORDER by id;")
        rows = mycursor.fetchall()
        return rows
    #level4 place
    def get_level4_p(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT level4 FROM place ORDER by level4;")
        rows = mycursor.fetchall()
        return rows
    def get_level4_name_p(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT level4_name FROM place ORDER by level4_name;")
        rows = mycursor.fetchall()
        return rows
    
    #level3 place
    def get_level3_p(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT level3 FROM place ORDER by level3;")
        rows = mycursor.fetchall()
        return rows
    def get_level3_name_p(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT level3_name FROM place ORDER by level3_name;")
        rows = mycursor.fetchall()
        return rows
    
    #level2 place
    def get_level2_p(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT level2 FROM place ORDER by level2;")
        rows = mycursor.fetchall()
        return rows
    def get_level2_name_p(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT level2_name FROM place ORDER by level2_name;")
        rows = mycursor.fetchall()
        return rows

    #level1 place
    def get_level1_p(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT level1 FROM place ORDER by level1;")
        rows = mycursor.fetchall()
        return rows
    def get_level1_name_p(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT level1_name FROM place ORDER by level1_name;")
        rows = mycursor.fetchall()
        return rows
    
    #namet item
    def get_namet(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT namet FROM item ORDER by namet;")
        rows = mycursor.fetchall()
        return rows
    def get_status1(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT status1 FROM item ORDER by status1;")
        rows = mycursor.fetchall()
        return rows
    def get_subtype_thai(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT subtype_thai FROM item ORDER by subtype_thai;")
        rows = mycursor.fetchall()
        return rows
    def get_subsubtype(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT subsubtype FROM item ORDER by subsubtype;")
        rows = mycursor.fetchall()
        return rows
    #owner table
    def get_font_name_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT font_name FROM owner ORDER by font_name;")
        rows = mycursor.fetchall()
        return rows
    def get_post_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT post FROM owner ORDER by post;")
        rows = mycursor.fetchall()
        return rows
    def get_olevel_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT olevel FROM owner ORDER by olevel;")
        rows = mycursor.fetchall()
        return rows
    def get_oroom_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT oroom FROM owner ORDER by oroom;")
        rows = mycursor.fetchall()
        return rows
    #olevel4 owner
    def get_olevel4_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT olevel4 FROM owner ORDER by olevel4;")
        rows = mycursor.fetchall()
        return rows
    def get_olevel4_name_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT olevel4_name FROM owner ORDER by olevel4_name;")
        rows = mycursor.fetchall()
        return rows
    #olevel3 owner
    def get_olevel3_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT olevel3 FROM owner ORDER by olevel3;")
        rows = mycursor.fetchall()
        return rows
    def get_olevel3_name_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT olevel3_name FROM owner ORDER by olevel3_name;")
        rows = mycursor.fetchall()
        return rows
    #olevel2 owner
    def get_olevel2_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT olevel2 FROM owner ORDER by olevel2;")
        rows = mycursor.fetchall()
        return rows
    def get_olevel2_name_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT olevel2_name FROM owner ORDER by olevel2_name;")
        rows = mycursor.fetchall()
        return rows
    #olevel1 owner
    def get_olevel1_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT olevel1 FROM owner ORDER by olevel1;")
        rows = mycursor.fetchall()
        return rows
    def get_olevel1_name_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT olevel1_name FROM owner ORDER by olevel1_name;")
        rows = mycursor.fetchall()
        return rows
    ##########################
    def get_wrooom_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT wrooom FROM owner ORDER by wrooom;")
        rows = mycursor.fetchall()
        return rows
    #wlevel4 owner
    def get_wlevel4_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT wlevel4 FROM owner ORDER by wlevel4;")
        rows = mycursor.fetchall()
        return rows
    def get_wlevel4_name_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT wlevel4_name FROM owner ORDER by wlevel4_name;")
        rows = mycursor.fetchall()
        return rows
    #wlevel3 owner
    def get_wlevel3_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT wlevel3 FROM owner ORDER by wlevel3;")
        rows = mycursor.fetchall()
        return rows
    def get_wlevel3_name_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT wlevel3_name FROM owner ORDER by wlevel3_name;")
        rows = mycursor.fetchall()
        return rows
    #wlevel2 owner
    def get_wlevel2_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT wlevel2 FROM owner ORDER by wlevel2;")
        rows = mycursor.fetchall()
        return rows
    def get_wlevel2_name_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT wlevel2_name FROM owner ORDER by wlevel2_name;")
        rows = mycursor.fetchall()
        return rows
    #wlevel1 owner
    def get_wlevel1_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT wlevel1 FROM owner ORDER by wlevel1;")
        rows = mycursor.fetchall()
        return rows
    def get_wlevel1_name_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT DISTINCT wlevel1_name FROM owner ORDER by wlevel1_name;")
        rows = mycursor.fetchall()
        return rows
        ############
    def get_name_all_ow(self):
        mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="item"
            )
        mycursor = mydb.cursor()
        mycursor.execute("SELECT name FROM owner;")
        rows = mycursor.fetchall()
        return rows