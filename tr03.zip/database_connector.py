import mysql.connector
from tkinter import *
from data_dropdown import *
class database_connector():
    def insert(self,id,namet,detail,band,model,serial,price,datec,howc,book,dateb,type_thai,subtype_thai,subsubtype,type,datet,status1,status2,status3,status4,status5,note,year,namer,namer_date,owner,place):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Insert into item values('"+ id +"','"+ namet +"','"+ detail +"','"+ band +"','"+ model +"','"+ serial +"','"+ price +"','"+ datec +"','"+ howc +"','"+ book +"','"+ dateb +"','"+ type_thai +"','"+ subtype_thai +"','"+ subsubtype +"','"+ type +"','"+ datet +"','"+ status1 +"','"+ status2 +"','"+ status3 +"','"+ status4 +"','"+ status5 +"','"+ note +"','"+ year +"','"+ namer +"','"+ namer_date +"','"+ owner +"','"+ place +"')")
        mycursor.execute("commit")
        mydb.close()
    def insert_place(self,id,name,tel,level1,level1_name,level2,level2_name,level3,level3_name,level4,level4_name):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Insert into place values('"+ id +"','"+ name +"','"+ tel +"','"+ level1 +"','"+ level1_name +"','"+ level2 +"','"+ level2_name +"','"+ level3 +"','"+ level3_name +"','"+ level4 +"','"+ level4_name +"')")
        mycursor.execute("commit")
        mydb.close()
    def insert_owner(self,font_name,name,post,olevel,oroom,oroom_name,otel,olevel1,olevel1_name,olevel2,olevel2_name,olevel3,olevel3_name,olevel4,olevel4_name,wrooom,wroom_name,wtel,wlevel1,wlevel1_name,wlevel2,wlevel2_name,wlevel3,wlevel3_name,wlevel4,wlevel4_name):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Insert into owner values('"+ font_name +"','"+ name +"','"+ post +"','"+ olevel +"','"+ oroom +"','"+ oroom_name +"','"+ otel +"','"+ olevel1 +"','"+ olevel1_name +"','"+ olevel2 +"','"+ olevel2_name +"','"+ olevel3 +"','"+ olevel3_name +"','"+ olevel4 +"','"+ olevel4_name +"','"+ wrooom +"','"+ wroom_name +"','"+ wtel +"','"+ wlevel1 +"','"+ wlevel1_name +"','"+ wlevel2 +"','"+ wlevel2_name +"','"+ wlevel3 +"','"+ wlevel3_name +"','"+ wlevel4 +"','"+ wlevel4_name +"')")
        mycursor.execute("commit")
        mydb.close()
    def insert_destroy(self,id,type,status,year,noyear,notype):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Insert into item2 values('"+ id +"','"+ type +"','"+ status +"','"+ year +"','"+ noyear +"','"+ notype +"')")
        mycursor.execute("commit")
        mydb.close()
    def insert_history(self,id,time,status_old,status_now,note_):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        mycursor = mydb.cursor()
        mycursor.execute("Insert into history_item values('"+ id +"','"+ time +"','"+ status_old +"','"+ status_now +"','"+ note_ +"')")
        mycursor.execute("commit")
        mydb.close()
    def delete(self,id):
        mydb = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    password="",
                    database="item"
                )
        mycursor = mydb.cursor()
        mycursor.execute("delete from item where id='"+ id +"'")
        mycursor.execute("commit")
        mydb.close()
    def delete_owner(self,name):
        mydb = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    password="",
                    database="item"
                )
        mycursor = mydb.cursor()
        mycursor.execute("delete from owner where name='"+ name +"'")
        mycursor.execute("commit")
        mydb.close()
    def delete_place(self,room):
        mydb = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    password="",
                    database="item"
                )
        mycursor = mydb.cursor()
        mycursor.execute("delete from place where id='"+ room +"'")
        mycursor.execute("commit")
        mydb.close()
    def update(self,id,namet,detail,band,model,serial,price,datec,howc,book,dateb,type_thai,subtype_thai,subsubtype,type,datet,status1,status2,status3,status4,status5,note,year,namer,namer_date,owner,place):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        mycursor = mydb.cursor()
        sql = "UPDATE item SET namet = %s,detail = %s,band = %s,model = %s,serial =%s ,price =%s , datec = %s ,howc = %s,book = %s , dateb=%s,type_thai = %s , subtype_thai=%s,subsubtype = %s , type=%s,datet = %s , status1=%s,status2 = %s , status3=%s,status4 = %s , status5=%s, note=%s, year=%s , namer=%s, namer_date=%s, owner=%s, place=%sWHERE  id= %s"
        val = (namet,detail,band,model,serial,price,datec,howc,book,dateb,type_thai,subtype_thai,subsubtype,type,datet,status1,status2,status3,status4,status5,note,year,namer,namer_date,owner,place,id)
        mycursor.execute(sql, val)
        mycursor.execute("commit")
        mydb.close()
    def update_owner(self,font_name,name,post,olevel,oroom,oroom_name,otel,olevel1,olevel1_name,olevel2,olevel2_name,olevel3,olevel3_name,olevel4,olevel4_name,wrooom,wroom_name,wtel,wlevel1,wlevel1_name,wlevel2,wlevel2_name,wlevel3,wlevel3_name,wlevel4,wlevel4_name):
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="item"
        )
        mycursor = mydb.cursor()
        sql = "UPDATE owner SET font_name = %s,post = %s,olevel = %s,oroom = %s,oroom_name =%s ,otel =%s , olevel1 = %s ,olevel1_name = %s,olevel2 = %s , olevel2_name=%s,olevel3 = %s , olevel3_name=%s,olevel4 = %s , olevel4_name=%s,wrooom = %s , wroom_name=%s,wtel = %s , wlevel1=%s,wlevel1_name = %s , wlevel2=%s, wlevel2_name=%s, wlevel3=%s , wlevel3_name=%s, wlevel4=%s, wlevel4_name=%s WHERE  name= %s"
        val = (font_name,post,olevel,oroom,oroom_name,otel,olevel1,olevel1_name,olevel2,olevel2_name,olevel3,olevel3_name,olevel4,olevel4_name,wrooom,wroom_name,wtel,wlevel1,wlevel1_name,wlevel2,wlevel2_name,wlevel3,wlevel3_name,wlevel4,wlevel4_name,name)
        mycursor.execute(sql, val)
        mycursor.execute("commit")
        mydb.close()
    allcount = []
    def InsertYearNO():
        mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="item"
            )
        mycursor = mydb.cursor()
        years = 1
        for i in year_all:
            for j in typeall:
                sql = "SELECT * FROM item2 WHERE year ='"+i+"' and type ='"+j+"'"
                mycursor.execute(sql)
                myresult = mycursor.fetchall()
                for x in myresult :
                    sql = "UPDATE SET noyear = '"+str(years)+"'WHERE id = '"+x[0]+"'"
                    years = years+1
                    pass
                
    def InserTypeNO():
        mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="item"
        )
        mycursor = mydb.cursor()
        tno = 1
        for i in typeall:
            sql = "SELECT * FROM item2 WHERE  type ='"+i+"'"
            mycursor.execute(sql)
            myresult = mycursor.fetchall()
            for x in myresult :
                sql = "UPDATE SET notype = '"+str(tno)+"'WHERE id = '"+x[0]+"'"
                tno = tno+1

database_connector.InsertYearNO()
database_connector.InserTypeNO()