from cProfile import label
from tkinter import *
from tkinter.ttk import *
from tkinter import ttk
import os
from tkcalendar import DateEntry
from database_connector import *
from table_ import  *
import tkinter.messagebox as MessageBox
from search_in_db import  *
from data_dropdown import *
from asyncio.windows_events import NULL
from PIL import Image
from PIL import ImageTk
import time as tm
import threading
root = Tk()
w = 1366
h = 768
bg_frame = '#ebfcfc'
root.geometry(f"{w}x{h}")
full_path = os.path.realpath(__file__)
full_dir = os.path.dirname(full_path)
image_path = 'img'
photo_ = PhotoImage(os.path.join(full_dir,image_path,'_C.ico'))
img  = Image.open(os.path.join(full_dir,image_path,'photo_top_frame-removebg.png'))
img = img.resize((110, 110))
photo_01=ImageTk.PhotoImage(img)
root.iconbitmap(photo_)
root.configure(bg = bg_frame)
root.title("ครุภัณฑ์เทศบาลนครแหลมฉบัง")
root.wm_attributes("-transparentcolor", 'grey')

id = StringVar()
namet = StringVar()
detail = StringVar()
band = StringVar()
model = StringVar()
serial = StringVar()
price = StringVar()
datec = StringVar()
howc = StringVar()
book = StringVar()
dateb = StringVar()
type_thai = StringVar()
subtype_thai = StringVar()
subsubtype = StringVar()
type = StringVar()
datet = StringVar()
status1 = StringVar()
status2 = StringVar()
status3 = StringVar()
status4 = StringVar()
status5 = StringVar()
note = StringVar()
name_place = StringVar()
room = StringVar()
year = StringVar()
#place table
tel = StringVar()
level4 = StringVar()
level4_name = StringVar()
level3 = StringVar()
level3_name = StringVar()
level2 = StringVar()
level2_name = StringVar()
level1 = StringVar()
level1_name = StringVar()
id_room_place = StringVar()
#owner table
font_name = StringVar()
name_font = StringVar()
name_last = StringVar()
post = StringVar()
olevel = StringVar()
oroom = StringVar()
oroom_name = StringVar()
otel = StringVar()
olevel1 = StringVar()
olevel1_name = StringVar()
olevel2 = StringVar()
olevel2_name = StringVar()
olevel3 = StringVar()
olevel3_name = StringVar()
olevel4 = StringVar()
olevel4_name = StringVar()
wrooom = StringVar()
wroom_name = StringVar()
wtel = StringVar()
wlevel1 = StringVar()
wlevel1_name = StringVar()
wlevel2 = StringVar()
wlevel2_name = StringVar()
wlevel3 = StringVar()
wlevel3_name = StringVar()
wlevel4 = StringVar()
wlevel4_name = StringVar()
name_full = StringVar()
namer = StringVar()
namer_date = StringVar()
owner = StringVar()
s_entry = StringVar()
s_entry_in = StringVar()

def bttn(x,y,text,cmd):
    mybutton = ttk.Button(root,text=text,style='font.TButton',command=cmd)#style='font.TButton'
    mybutton.place(relwidth = 0.155, relheight = 0.07, relx = x, rely = y)
    return mybutton
def time_():
    current_time = tm.strftime('%m/%d/%Y, %H:%M:%S:%p')
    ti.config(text=current_time,bg= bg_frame)
    ti.after(1000,time_)

global len_records
font_in =  Style()
font_in.configure('font_in.TButton',font=("TH Sarabun New",20,'bold'),)
font_re = Style()
font_re.configure('font_re.TButton',font=("TH Sarabun New",24,'bold'),)
s =  Style()
s.configure('top.TFrame',background = 'lightblue')
dropbox = Style()
dropbox.theme_use()
dropbox.configure('top.TButton',font=("TH Sarabun New",20,'bold'),background = 'lightgreen',relief="RAISED")#borderwidth = '4'
font01 =  Style()
font01.configure('font.TButton',font=("TH Sarabun New",20,'bold'),relief="RAISED",fg= 'black',background="lightgreen")#relief="flat" background="#ccc"
style =  Style()
style.theme_use()
style.configure("mystyle.Treeview",font=("TH Sarabun New",20),
	background="#D3D3D3",
	foreground="black",
	rowheight=30,
	fieldbackground="#D3D3D3")
style.configure("mystyle.Treeview.Heading", font=("TH Sarabun New",20,'bold'))
# Change Selected Color
style.map('mystyle.Treeview',
	background=[('selected', "#347083")])#347083
def get_detail_more():
    def set_zero():
        id.set("")
        namet.set("")
        detail.set("")
        band.set("")
        model.set("")
        serial.set("")
        price.set("")
        datec.set("")
        howc.set("")
        book.set("")
        dateb.set("")
        subtype_thai.set("")
        subsubtype.set("")
        type.set("")
        datet.set("")
        status1.set("")
        status2.set("")
        status3.set("")
        status4.set("")
        status5.set("")
        note.set("")
        room.set("")
        namer.set("")
        namer_date.set("")
        owner.set("")
    set_zero()
    top = Toplevel()
    top.geometry("1280x720")
    top.iconbitmap(photo_)
    top.title("รายละเอียดรหัสครุภัณฑ์")
    top.configure(bg=bg_frame)
    x_en = 0.185
    def label(top,x,y,text):
        label = ttk.Label(top,text = text,font=("TH Sarabun New",18,'bold'),background=bg_frame)
        label.place(relwidth = 0.2, relheight = 0.1, relx = x, rely = y)
    #id
    label(top,0.05,0.03,"รหัสครุภัณฑ์ :")
    entry_id = ttk.Entry(top,textvariable=id,font=("TH Sarabun New",18,'bold'))
    entry_id.place(relwidth = 0.14, relheight = 0.045, relx = x_en-0.05, rely = 0.05)
    #namethai
    label(top,0.05,0.11,"ชื่อประเภทไทย :")
    entry_namet = ttk.Entry(top,textvariable=namet,font=("TH Sarabun New",18,'bold'))
    entry_namet.place(relwidth = 0.32, relheight = 0.045, relx = x_en, rely = 0.13)
    #room
    label(top,0.05,0.19,"ห้อง:")
    entry_room = ttk.Entry(top,textvariable=room,font=("TH Sarabun New",20,'bold'))
    entry_room.place(relwidth = 0.1, relheight = 0.045, relx = x_en-0.1, rely = 0.21)
    #status 1
    label(top,0.05,0.27,"สถานะพัสดุปัจจุบัน:")
    entry_status1 = ttk.Entry(top,textvariable=status1,font=("TH Sarabun New",20,'bold'))
    entry_status1.place(relwidth = 0.14, relheight = 0.045, relx = x_en, rely = 0.29)
    #status 2
    label(top,0.455,0.27,"สถานะความรับผิดชอบ:")
    entry_status2 = ttk.Entry(top,textvariable=status2,font=("TH Sarabun New",20,'bold'))
    entry_status2.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.42, rely = 0.29)
    #status 3
    label(top,0.05,0.35,"สถานะการใช้งานปัจจุบัน:")
    entry_status3 = ttk.Entry(top,textvariable=status3,font=("TH Sarabun New",20,'bold'))
    entry_status3.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.011, rely = 0.37)
    #status 4 
    label(top,0.46,0.35,"สถานะการบำรุงรักษาล่าสุด:")
    entry_status4 = ttk.Entry(top,textvariable=status4,font=("TH Sarabun New",20,'bold'))
    entry_status4.place(relwidth = 0.155, relheight = 0.045, relx = x_en+0.45, rely = 0.37)
    #status 5
    label(top,0.05,0.43,"สถานะผลการตรวจสภาพ:")
    entry_status5 = ttk.Entry(top,textvariable=status5,font=("TH Sarabun New",20,'bold'))
    entry_status5.place(relwidth = 0.225, relheight = 0.045, relx = x_en+0.02, rely = 0.45)
    #band
    label(top,0.2,0.19,"ยี่ห้อ:")
    entry_band = ttk.Entry(top,textvariable=band,font=("TH Sarabun New",20,'bold'))
    entry_band.place(relwidth = 0.1, relheight = 0.045, relx = x_en+0.05, rely = 0.21)
    #model
    label(top,0.35,0.19,"รุ่น:")
    entry_model = ttk.Entry(top,textvariable=model,font=("TH Sarabun New",20,'bold'))
    entry_model.place(relwidth = 0.2, relheight = 0.045, relx = x_en+0.215, rely = 0.21)
    #serial
    label(top,0.625,0.19,"Serial:")
    entry_serial = ttk.Entry(top,textvariable=serial,font=("TH Sarabun New",20,'bold'))
    entry_serial.place(relwidth = 0.2, relheight = 0.045, relx = x_en+0.5, rely = 0.21)
    #price
    label(top,0.395,0.03,"ราคา :")
    entry_price = ttk.Entry(top,textvariable=price,font=("TH Sarabun New",18,'bold'))
    entry_price.place(relwidth = 0.14, relheight = 0.05, relx = x_en+0.25, rely = 0.05)
    #subtype_thai
    label(top,0.6,0.03,"ประเภท :")
    entry_subtype_thai = ttk.Entry(top,textvariable=subtype_thai,font=("TH Sarabun New",18,'bold'))
    entry_subtype_thai.place(relwidth = 0.175, relheight = 0.045, relx = x_en+0.495, rely = 0.05)
    #datec วันที่ได้รับมา
    label(top,0.05,0.5,"วันที่ได้รับมา :")
    entry_datec = ttk.Entry(top,textvariable=datec,font=("TH Sarabun New",18,'bold'))
    entry_datec.place(relwidth = 0.14, relheight = 0.045, relx = x_en-0.05, rely = 0.52)
    #dateb ลงวันที่
    label(top,0.3,0.5,"ลงวันที่ :")
    entry_dateb = ttk.Entry(top,textvariable=dateb,font=("TH Sarabun New",18,'bold'))
    entry_dateb.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.175, rely = 0.52)
    #datet วันที่ปรับสถานะวัสดุ
    label(top,0.525,0.5,"วันที่ปรับสถานะวัสดุ :")
    entry_datet = ttk.Entry(top,textvariable=datet,font=("TH Sarabun New",18,'bold'))
    entry_datet.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.485, rely = 0.52)
    #book ตามหนังสือที่
    label(top,0.05,0.57,"ตามหนังสือที่ :")
    entry_book = ttk.Entry(top,textvariable=book,font=("TH Sarabun New",18,'bold'))
    entry_book.place(relwidth = 0.14, relheight = 0.045, relx = x_en-0.05, rely = 0.59)
    #howc วิธีการได้มา
    label(top,0.3,0.57,"วิธีการได้มา :")
    entry_howc = ttk.Entry(top,textvariable=howc,font=("TH Sarabun New",18,'bold'))
    entry_howc.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.2, rely = 0.59)
    #subsubtype ประเภทย่อย-ท-
    label(top,0.535,0.57,"ประเภทย่อย-ท- :")
    entry_subsubtype = ttk.Entry(top,textvariable=subsubtype,font=("TH Sarabun New",18,'bold'))
    entry_subsubtype.place(relwidth = 0.175, relheight = 0.045, relx = x_en+0.45, rely = 0.59)
    #type ประเภทย่อย-อ-
    label(top,0.05,0.64,"ประเภทย่อย-อ- :")
    entry_type = ttk.Entry(top,textvariable=type,font=("TH Sarabun New",18,'bold'))
    entry_type.place(relwidth = 0.14, relheight = 0.045, relx = x_en, rely = 0.66)
    #detail รายละเอียด
    label(top,0.5,0.64,"รายละเอียด :")
    entry_detail = ttk.Entry(top,textvariable=detail,font=("TH Sarabun New",18,'bold'))
    entry_detail.place(relwidth = 0.4, relheight = 0.045, relx = x_en+0.4, rely = 0.66)
    #namer ผู้ให้ข้อมูล 
    label(top,0.05,0.71,"ผู้ให้ข้อมูล :")
    entry_namer = ttk.Entry(top,textvariable=namer,font=("TH Sarabun New",18,'bold'))
    entry_namer.place(relwidth = 0.2, relheight = 0.045, relx = x_en-0.05, rely = 0.73)
    #namer_date ณ วันที่
    label(top,0.35,0.71,"ณ วันที่ :")
    entry_namer_date = ttk.Entry(top,textvariable=namer_date,font=("TH Sarabun New",18,'bold'))
    entry_namer_date.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.225, rely = 0.73)
    #owner ผู้รับผิดชอบ
    label(top,0.575,0.71,"ผู้รับผิดชอบ :")
    entry_owner = ttk.Entry(top,textvariable=owner,font=("TH Sarabun New",18,'bold'))
    entry_owner.place(relwidth = 0.2, relheight = 0.045, relx = x_en+0.505, rely = 0.73)
    def search_id_up():
        temp = search_in_db()
        id_value = id.get()
        if(id_value ==""):
            MessageBox.showinfo("อัพเดตสถานะรหัสครุภัณฑ์","กรุณาใส่รหัสครุภัณฑ์",parent = top)
            return
        try:
            rows = temp.get_db(id_value)
            if rows[0]!= NULL:
                for i in rows:
                    # id.set(i[0])
                    namet.set(i[1])
                    detail.set(i[2])
                    band.set(i[3])
                    model.set(i[4])
                    serial.set(i[5])
                    price.set(i[6])
                    datec.set(i[7])
                    howc.set(i[8])
                    book.set(i[9])
                    dateb.set(i[10])
                    type_thai.set(i[11])
                    subtype_thai.set(i[12])
                    subsubtype.set(i[13])
                    type.set(i[14])
                    datet.set(i[15])
                    status1.set(i[16])
                    status2.set(i[17])
                    status3.set(i[18])
                    status4.set(i[19])
                    status5.set(i[20])
                    note.set(i[21])
                    namer.set(i[23])
                    namer_date.set(i[24])
                    owner.set(i[25])
                    room.set(i[26])
        except IndexError:
            MessageBox.showinfo("อัพเดตสถานะรหัสครุภัณฑ์","ไม่พบรหัสครุภัณฑ์ : " + id_value,parent = top)

    search_ = ttk.Button(top,text="ค้นหา",style='font_in.TButton',command= lambda:search_id_up()).place(relx = x_en+0.1, rely = 0.04)
    search_place = ttk.Button(top,text="หาห้อง",style='font_in.TButton',command= lambda:get_detial_place()).place(relx = x_en+0.15, rely = 0.85)
    search_owner = ttk.Button(top,text="หาผู้ดูแล",style='font_in.TButton',command= lambda:get_detail_owner()).place(relx = x_en+0.25, rely = 0.85)
    b =  ttk.Button(top,text="ยุบสภาพ",style='font_in.TButton',command= lambda:show_destroy()).place(relx = x_en+0.35, rely = 0.85)
def get_detail():
    def set_zero():
        id.set("")
        namet.set("")
        detail.set("")
        band.set("")
        model.set("")
        serial.set("")
        price.set("")
        datec.set("")
        howc.set("")
        book.set("")
        dateb.set("")
        subtype_thai.set("")
        subsubtype.set("")
        type.set("")
        datet.set("")
        status1.set("")
        status2.set("")
        status3.set("")
        status4.set("")
        status5.set("")
        note.set("")
        room.set("")
        namer.set("")
        namer_date.set("")
        owner.set("")
    set_zero()
    top = Toplevel()
    top.geometry("1280x720")
    top.iconbitmap(photo_)
    top.title("อัพเดตรหัสครุภัณฑ์")
    top.configure(bg=bg_frame)
    x_en = 0.185
    def set_owner(e):
        owner.set("")
        entry_owner.insert(0,owner_clicked.get())
    def set_namer(e):
        namer.set("")
        entry_namer.insert(0,namer_clicked.get())
    def set_room(e):
        room.set("")
        entry_room.insert(0,room_clicked.get())
    def set_subtype_thai(e):
        subtype_thai.set("")
        entry_subtype_thai.insert(0,subtype_thai_clicked.get())
    def set_status1(e):
        status1.set("")
        entry_status1.insert(0,status1_clicked.get())
    def set_status2(e):
        status2.set("")
        entry_status2.insert(0,status2_clicked.get())
    def set_status3(e):
        status3.set("")
        entry_status3.insert(0,status3_clicked.get())
    def set_status4(e):
        status4.set("")
        entry_status4.insert(0,status4_clicked.get())
    def set_status5(e):
        status5.set("")
        entry_status5.insert(0,status5_clicked.get())
    def set_namet(e):
        namet.set("")
        entry_namet.insert(0,clicked1.get())
    def set_type(e):
        type.set("")
        entry_type.insert(0,type_clicked.get())
    def set_subsubtype(e):
        subsubtype.set("")
        entry_subsubtype.insert(0,subsubtype_clicked.get())
    def label(top,x,y,text):
        label = ttk.Label(top,text = text,font=("TH Sarabun New",18,'bold'),background=bg_frame)
        label.place(relwidth = 0.2, relheight = 0.1, relx = x, rely = y)
    status1_clicked = StringVar()
    clicked1 = StringVar()
    status2_clicked = StringVar()
    status3_clicked = StringVar()
    status4_clicked = StringVar()
    status5_clicked = StringVar()
    subtype_thai_clicked = StringVar()
    subsubtype_clicked = StringVar()
    type_clicked = StringVar()
    room_clicked = StringVar()
    namer_clicked = StringVar()
    owner_clicked = StringVar()
    #id
    label(top,0.05,0.03,"รหัสครุภัณฑ์ :")
    entry_id = ttk.Entry(top,textvariable=id,font=("TH Sarabun New",18,'bold'))
    entry_id.place(relwidth = 0.14, relheight = 0.045, relx = x_en-0.05, rely = 0.05)
    #namethai
    label(top,0.05,0.11,"ชื่อประเภทไทย :")
    entry_namet = ttk.Entry(top,textvariable=namet,font=("TH Sarabun New",18,'bold'))
    entry_namet.place(relwidth = 0.32, relheight = 0.045, relx = x_en, rely = 0.13)
    namet_com = ttk.Combobox(top,justify='center',textvariable=clicked1,font=("TH Sarabun New",18), values = namet_ )
    namet_com.set(namet_[0])
    namet_com.bind("<<ComboboxSelected>>", set_namet)
    namet_com.place(relwidth = 0.275, relheight = 0.045, relx = x_en+0.35, rely = 0.13)
    #room
    label(top,0.05,0.19,"ห้อง:")
    entry_room = ttk.Entry(top,textvariable=room,font=("TH Sarabun New",20,'bold'))
    entry_room.place(relwidth = 0.1, relheight = 0.045, relx = x_en-0.1, rely = 0.21)
    room_c = ttk.Combobox(top,justify='center',textvariable=room_clicked,font=("TH Sarabun New",18), values = room_db )
    room_c.set(room_db[0])
    room_c.bind("<<ComboboxSelected>>", set_room)
    room_c.place(relwidth = 0.1, relheight = 0.045, relx = x_en+0.005, rely = 0.21)
    #status 1
    label(top,0.05,0.27,"สถานะพัสดุปัจจุบัน:")
    entry_status1 = ttk.Entry(top,textvariable=status1,font=("TH Sarabun New",20,'bold'))
    entry_status1.place(relwidth = 0.14, relheight = 0.045, relx = x_en, rely = 0.29)
    status1_c = ttk.Combobox(top,justify='center',textvariable=status1_clicked,font=("TH Sarabun New",18), values = status1_dp_all )
    status1_c.set(status1_dp_all[0])
    status1_c.bind("<<ComboboxSelected>>", set_status1)
    status1_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.145, rely = 0.29)
    #status 2
    label(top,0.455,0.27,"สถานะความรับผิดชอบ:")
    entry_status2 = ttk.Entry(top,textvariable=status2,font=("TH Sarabun New",20,'bold'))
    entry_status2.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.42, rely = 0.29)
    status2_c = ttk.Combobox(top,justify='center',textvariable=status2_clicked,font=("TH Sarabun New",18), values = status2_dp_all )
    status2_c.set(status2_dp_all[0])
    status2_c.bind("<<ComboboxSelected>>", set_status2)
    status2_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.575, rely = 0.29)
    #status 3
    label(top,0.05,0.35,"สถานะการใช้งานปัจจุบัน:")
    entry_status3 = ttk.Entry(top,textvariable=status3,font=("TH Sarabun New",20,'bold'))
    entry_status3.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.011, rely = 0.37)
    status3_c = ttk.Combobox(top,justify='center',textvariable=status3_clicked,font=("TH Sarabun New",18), values = status3_dp_all )
    status3_c.set(status3_dp_all[0])
    status3_c.bind("<<ComboboxSelected>>", set_status3)
    status3_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.15725, rely = 0.37)
    #status 4 
    label(top,0.46,0.35,"สถานะการบำรุงรักษาล่าสุด:")
    entry_status4 = ttk.Entry(top,textvariable=status4,font=("TH Sarabun New",20,'bold'))
    entry_status4.place(relwidth = 0.155, relheight = 0.045, relx = x_en+0.45, rely = 0.37)
    status4_c = ttk.Combobox(top,justify='center',textvariable=status4_clicked,font=("TH Sarabun New",18), values = status4_dp_all )
    status4_c.set(status4_dp_all[0])
    status4_c.bind("<<ComboboxSelected>>", set_status4)
    status4_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.62, rely = 0.37)
    #status 5
    label(top,0.05,0.43,"สถานะผลการตรวจสภาพ:")
    entry_status5 = ttk.Entry(top,textvariable=status5,font=("TH Sarabun New",20,'bold'))
    entry_status5.place(relwidth = 0.225, relheight = 0.045, relx = x_en+0.02, rely = 0.45)
    status5_c = ttk.Combobox(top,justify='center',textvariable=status5_clicked,font=("TH Sarabun New",18), values = status5_dp_all )
    status5_c.set(status5_dp_all[0])
    status5_c.bind("<<ComboboxSelected>>", set_status5)
    status5_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.25, rely = 0.45)
    #band
    label(top,0.3,0.19,"ยี่ห้อ:")
    entry_band = ttk.Entry(top,textvariable=band,font=("TH Sarabun New",20,'bold'))
    entry_band.place(relwidth = 0.1, relheight = 0.045, relx = x_en+0.15, rely = 0.21)
    #model
    label(top,0.45,0.19,"รุ่น:")
    entry_model = ttk.Entry(top,textvariable=model,font=("TH Sarabun New",20,'bold'))
    entry_model.place(relwidth = 0.2, relheight = 0.045, relx = x_en+0.315, rely = 0.21)
    #serial
    label(top,0.725,0.19,"Serial:")
    entry_serial = ttk.Entry(top,textvariable=serial,font=("TH Sarabun New",20,'bold'))
    entry_serial.place(relwidth = 0.2, relheight = 0.045, relx = x_en+0.6, rely = 0.21)
    #price
    label(top,0.395,0.03,"ราคา :")
    entry_price = ttk.Entry(top,textvariable=price,font=("TH Sarabun New",18,'bold'))
    entry_price.place(relwidth = 0.14, relheight = 0.05, relx = x_en+0.25, rely = 0.05)
    #subtype_thai
    label(top,0.6,0.03,"ประเภท :")
    entry_subtype_thai = ttk.Entry(top,textvariable=subtype_thai,font=("TH Sarabun New",18,'bold'))
    entry_subtype_thai.place(relwidth = 0.175, relheight = 0.045, relx = x_en+0.495, rely = 0.05)
    subtype_thai_c = ttk.Combobox(top,justify='center',textvariable=subtype_thai_clicked,font=("TH Sarabun New",18), values = subtype_thai_dp )
    subtype_thai_c.set(subtype_thai_dp[0])
    subtype_thai_c.bind("<<ComboboxSelected>>", set_subtype_thai)
    subtype_thai_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.685, rely = 0.05)
    #datec วันที่ได้รับมา
    label(top,0.05,0.5,"วันที่ได้รับมา :")
    # entry_datec = DateEntry(top,selectmode = 'day',textvariable=datec,font=("TH Sarabun New",18,'bold'))
    # entry_datec.place(relwidth = 0.1, relheight = 0.045,relx = x_en-0.05, rely = 0.52)
    entry_datec = ttk.Entry(top,textvariable=datec,font=("TH Sarabun New",18,'bold'))
    entry_datec.place(relwidth = 0.14, relheight = 0.045, relx = x_en-0.05, rely = 0.52)
    #dateb ลงวันที่
    label(top,0.3,0.5,"ลงวันที่ :")
    entry_dateb = ttk.Entry(top,textvariable=dateb,font=("TH Sarabun New",18,'bold'))
    entry_dateb.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.175, rely = 0.52)
    #datet วันที่ปรับสถานะวัสดุ
    label(top,0.525,0.5,"วันที่ปรับสถานะวัสดุ :")
    entry_datet = ttk.Entry(top,textvariable=datet,font=("TH Sarabun New",18,'bold'))
    entry_datet.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.485, rely = 0.52)
    #book ตามหนังสือที่
    label(top,0.05,0.57,"ตามหนังสือที่ :")
    entry_book = ttk.Entry(top,textvariable=book,font=("TH Sarabun New",18,'bold'))
    entry_book.place(relwidth = 0.14, relheight = 0.045, relx = x_en-0.05, rely = 0.59)
    #howc วิธีการได้มา
    label(top,0.3,0.57,"วิธีการได้มา :")
    entry_howc = ttk.Entry(top,textvariable=howc,font=("TH Sarabun New",18,'bold'))
    entry_howc.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.2, rely = 0.59)
    #subsubtype ประเภทย่อย-ท-
    label(top,0.535,0.57,"ประเภทย่อย-ท- :")
    entry_subsubtype = ttk.Entry(top,textvariable=subsubtype,font=("TH Sarabun New",18,'bold'))
    entry_subsubtype.place(relwidth = 0.175, relheight = 0.045, relx = x_en+0.45, rely = 0.59)
    subsubtype_c = ttk.Combobox(top,justify='center',textvariable=subsubtype_clicked,font=("TH Sarabun New",18), values = subsubtype_db )
    subsubtype_c.set(subsubtype_db[0])
    subsubtype_c.bind("<<ComboboxSelected>>", set_subsubtype)
    subsubtype_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.65, rely = 0.59)
    #type ประเภทย่อย-อ-
    label(top,0.05,0.64,"ประเภทย่อย-อ- :")
    entry_type = ttk.Entry(top,textvariable=type,font=("TH Sarabun New",18,'bold'))
    entry_type.place(relwidth = 0.14, relheight = 0.045, relx = x_en, rely = 0.66)
    type_c = ttk.Combobox(top,justify='center',textvariable=type_clicked,font=("TH Sarabun New",20), values = type_db )
    type_c.set(type_db[0])
    type_c.bind("<<ComboboxSelected>>", set_type)
    type_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.15, rely = 0.66)
    #detail รายละเอียด
    label(top,0.5,0.64,"รายละเอียด :")
    entry_detail = ttk.Entry(top,textvariable=detail,font=("TH Sarabun New",18,'bold'))
    entry_detail.place(relwidth = 0.4, relheight = 0.045, relx = x_en+0.4, rely = 0.66)
    #note หมายเหตุ
    label(top,0.5,0.78,"หมายเหตุ :")
    entry_note = ttk.Entry(top,textvariable=note,font=("TH Sarabun New",18,'bold'))
    entry_note.place(relwidth = 0.4,relheight = 0.045, relx = x_en+0.4, rely = 0.80)
    #namer ผู้ให้ข้อมูล 
    label(top,0.05,0.71,"ผู้ให้ข้อมูล :")
    entry_namer = ttk.Entry(top,textvariable=namer,font=("TH Sarabun New",18,'bold'))
    entry_namer.place(relwidth = 0.2, relheight = 0.045, relx = x_en-0.05, rely = 0.73)
    namer_c = ttk.Combobox(top,justify='center',textvariable=namer_clicked,font=("TH Sarabun New",20), values = namer_db )
    namer_c.set("ชื่อผู้ให้ข้อมูลทั้งหมด")
    namer_c.bind("<<ComboboxSelected>>", set_namer)
    namer_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.155, rely = 0.73)
    #namer_date ณ วันที่
    ttk.Label(top,text="ณ วันที่ :",font=("TH Sarabun New",18,'bold'),background=bg_frame).place(relx=0.5,rely=0.73)
    # entry_namer_date = DateEntry(top,selectmode = 'day',textvariable=namer_date,font=("TH Sarabun New",18,'bold'))
    # entry_namer_date.place(relwidth = 0.1, relheight = 0.045,relx = x_en+0.5, rely = 0.73)
    entry_namer_date = ttk.Entry(top,textvariable=namer_date,font=("TH Sarabun New",18,'bold'))
    entry_namer_date.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.4, rely = 0.73)
    #owner ผู้รับผิดชอบ
    label(top,0.05,0.78,"ผู้รับผิดชอบ :")
    entry_owner = ttk.Entry(top,textvariable=owner,font=("TH Sarabun New",18,'bold'))
    entry_owner.place(relwidth = 0.2, relheight = 0.045, relx = x_en-0.05, rely = 0.80)
    owner_c = ttk.Combobox(top,justify='center',textvariable=owner_clicked,font=("TH Sarabun New",20), values = owner_db )
    owner_c.set("ชื่อผู้รับผิดชอบทั้งหมดทั้งหมด")
    owner_c.bind("<<ComboboxSelected>>", set_owner)
    owner_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.155, rely = 0.80)
    def search_id_up():
        global status_old
        temp = search_in_db()
        id_value = id.get()
        if(id_value ==""):
            MessageBox.showinfo("อัพเดตสถานะรหัสครุภัณฑ์","กรุณาใส่รหัสครุภัณฑ์",parent = top)
            return
        try:
            rows = temp.get_db(id_value)
            if rows[0]!= NULL:
                for i in rows:
                    # id.set(i[0])
                    namet.set(i[1])
                    detail.set(i[2])
                    band.set(i[3])
                    model.set(i[4])
                    serial.set(i[5])
                    price.set(i[6])
                    datec.set(i[7])
                    howc.set(i[8])
                    book.set(i[9])
                    dateb.set(i[10])
                    type_thai.set(i[11])
                    subtype_thai.set(i[12])
                    subsubtype.set(i[13])
                    type.set(i[14])
                    datet.set(i[15])
                    status1.set(i[16])
                    status2.set(i[17])
                    status3.set(i[18])
                    status_old = i[18]
                    status4.set(i[19])
                    status5.set(i[20])
                    note.set(i[21])
                    namer.set(i[23])
                    namer_date.set(i[24])
                    owner.set(i[25])
                    room.set(i[26])
        except IndexError:
            MessageBox.showinfo("อัพเดตสถานะรหัสครุภัณฑ์","ไม่พบรหัสครุภัณฑ์ : " + id_value,parent = top)
    def update_database():
        temp = database_connector()
        id_value = id.get()
        namet_value = namet.get()
        year_value = ""
        band_value = band.get()
        model_value = model.get()
        serial_value = serial.get()
        price_value = price.get()
        datec_value = datec.get()
        howc_value = howc.get()
        book_value = book.get()
        dateb_value = dateb.get()
        type_thai_value = type_thai.get()
        subtype_thai_value = namet.get() #subtype_thai.get()
        subsubtype_value = subsubtype.get()
        type_value = type.get()
        datet_value = datet.get()
        status1_value = status1.get()
        status2_value = status2.get()
        status3_value = status3.get()
        status4_value = status4.get()
        status5_value = status5.get()
        note_value = note.get()
        detail_value = detail.get()
        namer_value = namer.get()
        namer_date_value = namer_date.get()
        owner_value = owner.get()
        room_value = room.get()
        for i in id_value.split('-') :
            if len(i)%2==0:
                year_value = i
                break
        if(id_value ==""):
            MessageBox.showinfo("อัพเดตสถานะรหัสครุภัณฑ์","กรุณาใส่ข้อมูล",parent = top)
            return
        try:
            current_time = tm.strftime('%m/%d/%Y, %H:%M:%S:%p')
            temp.update(id_value,namet_value,detail_value,band_value,model_value,serial_value,price_value,datec_value,howc_value,book_value,dateb_value,type_thai_value,subtype_thai_value,subsubtype_value,type_value,datet_value,status1_value,status2_value,status3_value,status4_value,status5_value,note_value,year_value,namer_value,namer_date_value,owner_value,room_value)
            temp.insert_history(id_value,current_time,status_old,status3_value,note_value)
            set_zero()
            MessageBox.showinfo("อัพเดตสถานะรหัสครุภัณฑ์","Successfully",parent = top,)
            threading.Thread(target=search1(1)).start()
            # all_year()
        except IndexError:
            MessageBox.showinfo("อัพเดตสถานะรหัสครุภัณฑ์","????? : " + id_value,parent = top)
            set_zero()
    search_ = ttk.Button(top,text="ค้นหา",style='font_in.TButton',command= lambda:search_id_up()).place(relx = x_en+0.1, rely = 0.04)#relheight=0.085,relwidth=0.1
    insert = ttk.Button(top,text="อัพเดต",style='font_in.TButton',command=lambda:update_database()).place( relx = x_en+0.65, rely = 0.9)

def delete_database():
    id.set("")
    note.set("")
    top = Toplevel()
    top.geometry("500x240+150+150")
    top.iconbitmap(photo_)
    top.title("ลบรหัสครุภัณฑ์")
    top.configure(bg=bg_frame)
    temp = database_connector()
    tem = search_in_db()
    x_en = 0.45
    def label(top,x,y,text):
        label = ttk.Label(top,text = text,font=("TH Sarabun New",24,'bold'),background=bg_frame)
        label.place(relwidth = 0.3, relheight = 0.15, relx = x, rely = y)
    label(top,0.1,0.1,"รหัสครุภัณฑ์ :")
    def ask():
        return MessageBox.askyesno("ลบข้อมูล", "ต้องการลบครุภัณฑ์ : "+id.get()+" ?",parent = top)
    def delete_():
        id_value = id.get()
        note_value = note.get()
        if(id_value ==""):
            MessageBox.showinfo("ลบข้อมูล","กรุณาใส่ข้อมูลรหัสครุภัณฑ์",parent = top)
            return
        if ask():
            try :
                rows = tem.get_db(id_value)
                for i in rows:
                    type_value = i[14]
                    status_old = i[18]
                    year_value = i[22]
                current_time = tm.strftime('%m/%d/%Y, %H:%M:%S:%p')
                temp.delete(id_value)
                temp.insert_destroy(id_value,type_value,"ยุบสภาพ",year_value,"","")
                temp.insert_history(id_value,current_time,status_old,"ลบ",note_value)
                MessageBox.showinfo("ลบข้อมูล","ลบข้อมูลแล้ว "+id_value,parent = top)
                id.set("")
                note.set("")
                threading.Thread(target=search1(1)).start()
                # all_year()
            except:
                id.set("")
                note.set("")
                MessageBox.showinfo("ลบข้อมูล","ไม่พบข้อมูลที่จะลบหรือเคยลบข้อมูลนี้แล้ว",icon ='error',parent = top)
                threading.Thread(target=search1(1)).start()
        else :
            return
    entry_id = ttk.Entry(top,textvariable=id,font=("TH Sarabun New",24,'bold')).place(relwidth = 0.3, relheight = 0.115, relx = x_en, rely = 0.12)
    label(top,0.1,0.28,"หมายเหตุ :")
    entry_note = ttk.Entry(top,textvariable=note,font=("TH Sarabun New",24,'bold')).place(relwidth = 0.3, relheight = 0.115, relx = x_en, rely = 0.3)
    b = ttk.Button(top,text="ลบข้อมูล",style='font_in.TButton',command=lambda:delete_()).place(relwidth = 0.2, relheight = 0.175, relx = 0.71, rely = 0.75)

def insert_database_item():
    def set_zero():
        id.set("")
        namet.set("")
        detail.set("")
        band.set("")
        model.set("")
        serial.set("")
        price.set("")
        datec.set("")
        howc.set("")
        book.set("")
        dateb.set("")
        subtype_thai.set("")
        subsubtype.set("")
        type.set("")
        datet.set("")
        status1.set("")
        status2.set("")
        status3.set("")
        status4.set("")
        status5.set("")
        note.set("")
        room.set("")
        namer.set("")
        namer_date.set("")
        owner.set("")
    set_zero()
    top = Toplevel()
    top.geometry("1280x720")
    top.iconbitmap(photo_)
    top.title("เพิ่มรหัสครุภัณฑ์")
    top.configure(bg=bg_frame)
    x_en = 0.185
    def set_owner(e):
        owner.set("")
        entry_owner.insert(0,owner_clicked.get())
    def set_namer(e):
        namer.set("")
        entry_namer.insert(0,namer_clicked.get())
    def set_room(e):
        room.set("")
        entry_room.insert(0,room_clicked.get())
    def set_subtype_thai(e):
        subtype_thai.set("")
        entry_subtype_thai.insert(0,subtype_thai_clicked.get())
    def set_status1(e):
        status1.set("")
        entry_status1.insert(0,status1_clicked.get())
    def set_status2(e):
        status2.set("")
        entry_status2.insert(0,status2_clicked.get())
    def set_status3(e):
        status3.set("")
        entry_status3.insert(0,status3_clicked.get())
    def set_status4(e):
        status4.set("")
        entry_status4.insert(0,status4_clicked.get())
    def set_status5(e):
        status5.set("")
        entry_status5.insert(0,status5_clicked.get())
    def set_namet(e):
        namet.set("")
        entry_namet.insert(0,clicked1.get())
    def set_type(e):
        type.set("")
        entry_type.insert(0,type_clicked.get())
    def set_subsubtype(e):
        subsubtype.set("")
        entry_subsubtype.insert(0,subsubtype_clicked.get())
    def label(top,x,y,text):
        label = ttk.Label(top,text = text,font=("TH Sarabun New",18,'bold'),background=bg_frame)
        label.place(relwidth = 0.2, relheight = 0.1, relx = x, rely = y)
    status1_clicked = StringVar()
    clicked1 = StringVar()
    status2_clicked = StringVar()
    status3_clicked = StringVar()
    status4_clicked = StringVar()
    status5_clicked = StringVar()
    subtype_thai_clicked = StringVar()
    subsubtype_clicked = StringVar()
    type_clicked = StringVar()
    room_clicked = StringVar()
    namer_clicked = StringVar()
    owner_clicked = StringVar()
    #id
    label(top,0.05,0.03,"รหัสครุภัณฑ์ :")
    entry_id = ttk.Entry(top,textvariable=id,font=("TH Sarabun New",18,'bold'))
    entry_id.place( relx = x_en-0.05, rely = 0.05)
    #namethai
    label(top,0.05,0.11,"ชื่อประเภทไทย :")
    entry_namet = ttk.Entry(top,textvariable=namet,font=("TH Sarabun New",18,'bold'))
    entry_namet.place(relwidth = 0.32, relheight = 0.045, relx = x_en, rely = 0.13)
    namet_com = ttk.Combobox(top,justify='center',textvariable=clicked1,font=("TH Sarabun New",18), values = namet_ )
    namet_com.set(namet_[0])
    namet_com.bind("<<ComboboxSelected>>", set_namet)
    namet_com.place(relwidth = 0.275, relheight = 0.045, relx = x_en+0.35, rely = 0.13)
    #room
    label(top,0.05,0.19,"ห้อง:")
    entry_room = ttk.Entry(top,textvariable=room,font=("TH Sarabun New",20,'bold'))
    entry_room.place(relwidth = 0.1, relheight = 0.045, relx = x_en-0.1, rely = 0.21)
    room_c = ttk.Combobox(top,justify='center',textvariable=room_clicked,font=("TH Sarabun New",20), values = room_db )
    room_c.set(room_db[0])
    room_c.bind("<<ComboboxSelected>>", set_room)
    room_c.place(relwidth = 0.1, relheight = 0.045, relx = x_en+0.005, rely = 0.21)
    #status 1
    label(top,0.05,0.27,"สถานะพัสดุปัจจุบัน:")
    entry_status1 = ttk.Entry(top,textvariable=status1,font=("TH Sarabun New",20,'bold'))
    entry_status1.place(relwidth = 0.14, relheight = 0.045, relx = x_en, rely = 0.29)
    status1_c = ttk.Combobox(top,justify='center',textvariable=status1_clicked,font=("TH Sarabun New",20), values = status1_dp_all )
    status1_c.set(status1_dp_all[0])
    status1_c.bind("<<ComboboxSelected>>", set_status1)
    status1_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.145, rely = 0.29)
    #status 2
    label(top,0.455,0.27,"สถานะความรับผิดชอบ:")
    entry_status2 = ttk.Entry(top,textvariable=status2,font=("TH Sarabun New",20,'bold'))
    entry_status2.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.42, rely = 0.29)
    status2_c = ttk.Combobox(top,justify='center',textvariable=status2_clicked,font=("TH Sarabun New",20), values = status2_dp_all )
    status2_c.set(status2_dp_all[0])
    status2_c.bind("<<ComboboxSelected>>", set_status2)
    status2_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.575, rely = 0.29)
    #status 3
    label(top,0.05,0.35,"สถานะการใช้งานปัจจุบัน:")
    entry_status3 = ttk.Entry(top,textvariable=status3,font=("TH Sarabun New",20,'bold'))
    entry_status3.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.011, rely = 0.37)
    status3_c = ttk.Combobox(top,justify='center',textvariable=status3_clicked,font=("TH Sarabun New",20), values = status3_dp_all )
    status3_c.set(status3_dp_all[0])
    status3_c.bind("<<ComboboxSelected>>", set_status3)
    status3_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.15725, rely = 0.37)
    #status 4 
    label(top,0.46,0.35,"สถานะการบำรุงรักษาล่าสุด:")
    entry_status4 = ttk.Entry(top,textvariable=status4,font=("TH Sarabun New",20,'bold'))
    entry_status4.place(relwidth = 0.155, relheight = 0.045, relx = x_en+0.45, rely = 0.37)
    status4_c = ttk.Combobox(top,justify='center',textvariable=status4_clicked,font=("TH Sarabun New",20), values = status4_dp_all )
    status4_c.set(status4_dp_all[0])
    status4_c.bind("<<ComboboxSelected>>", set_status4)
    status4_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.62, rely = 0.37)
    #status 5
    label(top,0.05,0.43,"สถานะผลการตรวจสภาพ:")
    entry_status5 = ttk.Entry(top,textvariable=status5,font=("TH Sarabun New",20,'bold'))
    entry_status5.place(relwidth = 0.225, relheight = 0.045, relx = x_en+0.02, rely = 0.45)
    status5_c = ttk.Combobox(top,justify='center',textvariable=status5_clicked,font=("TH Sarabun New",20), values = status5_dp_all )
    status5_c.set(status5_dp_all[0])
    status5_c.bind("<<ComboboxSelected>>", set_status5)
    status5_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.25, rely = 0.45)
    #band
    label(top,0.3,0.19,"ยี่ห้อ:")
    entry_band = ttk.Entry(top,textvariable=band,font=("TH Sarabun New",20,'bold'))
    entry_band.place(relwidth = 0.1, relheight = 0.045, relx = x_en+0.15, rely = 0.21)
    #model
    label(top,0.45,0.19,"รุ่น:")
    entry_model = ttk.Entry(top,textvariable=model,font=("TH Sarabun New",20,'bold'))
    entry_model.place(relwidth = 0.2, relheight = 0.045, relx = x_en+0.315, rely = 0.21)
    #serial
    label(top,0.725,0.19,"Serial:")
    entry_serial = ttk.Entry(top,textvariable=serial,font=("TH Sarabun New",20,'bold'))
    entry_serial.place(relwidth = 0.2, relheight = 0.045, relx = x_en+0.6, rely = 0.21)
    #price
    label(top,0.3,0.03,"ราคา :")
    entry_price = ttk.Entry(top,textvariable=price,font=("TH Sarabun New",18,'bold'))
    entry_price.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.185, rely = 0.05)
    #subtype_thai
    label(top,0.525,0.03,"ประเภท :")
    entry_subtype_thai = ttk.Entry(top,textvariable=subtype_thai,font=("TH Sarabun New",18,'bold'))
    entry_subtype_thai.place(relwidth = 0.175, relheight = 0.045, relx = x_en+0.41, rely = 0.05)
    subtype_thai_c = ttk.Combobox(top,justify='center',textvariable=subtype_thai_clicked,font=("TH Sarabun New",20), values = subtype_thai_dp )
    subtype_thai_c.set(subtype_thai_dp[0])
    subtype_thai_c.bind("<<ComboboxSelected>>", set_subtype_thai)
    subtype_thai_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.6, rely = 0.05)
    #datec วันที่ได้รับมา
    label(top,0.05,0.5,"วันที่ได้รับมา :")
    entry_datec = DateEntry(top,selectmode = 'day',textvariable=datec,font=("TH Sarabun New",18,'bold'))
    entry_datec.place(relwidth = 0.1, relheight = 0.045,relx = x_en-0.05, rely = 0.52)
    #dateb ลงวันที่
    label(top,0.3,0.5,"ลงวันที่ :")
    entry_dateb = DateEntry(top,selectmode = 'day',textvariable=dateb,font=("TH Sarabun New",18,'bold'))
    entry_dateb.place(relwidth = 0.1, relheight = 0.045,relx = x_en+0.175, rely = 0.52)
    #datet วันที่ปรับสถานะวัสดุ
    label(top,0.525,0.5,"วันที่ปรับสถานะวัสดุ :")
    entry_datet = DateEntry(top,selectmode = 'day',textvariable=datet,font=("TH Sarabun New",18,'bold'))
    entry_datet.place(relwidth = 0.1, relheight = 0.045,relx = x_en+0.485, rely = 0.52)
    #book ตามหนังสือที่
    label(top,0.05,0.57,"ตามหนังสือที่ :")
    entry_book = ttk.Entry(top,textvariable=book,font=("TH Sarabun New",18,'bold'))
    entry_book.place(relwidth = 0.14, relheight = 0.045, relx = x_en-0.05, rely = 0.59)
    #howc วิธีการได้มา
    label(top,0.3,0.57,"วิธีการได้มา :")
    entry_howc = ttk.Entry(top,textvariable=howc,font=("TH Sarabun New",18,'bold'))
    entry_howc.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.2, rely = 0.59)
    #subsubtype ประเภทย่อย-ท-
    label(top,0.535,0.57,"ประเภทย่อย-ท- :")
    entry_subsubtype = ttk.Entry(top,textvariable=subsubtype,font=("TH Sarabun New",18,'bold'))
    entry_subsubtype.place(relwidth = 0.175, relheight = 0.045, relx = x_en+0.45, rely = 0.59)
    subsubtype_c = ttk.Combobox(top,justify='center',textvariable=subsubtype_clicked,font=("TH Sarabun New",20), values = subsubtype_db )
    subsubtype_c.set(subsubtype_db[0])
    subsubtype_c.bind("<<ComboboxSelected>>", set_subsubtype)
    subsubtype_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.65, rely = 0.59)
    #type ประเภทย่อย-อ-
    label(top,0.05,0.64,"ประเภทย่อย-อ- :")
    entry_type = ttk.Entry(top,textvariable=type,font=("TH Sarabun New",18,'bold'))
    entry_type.place(relwidth = 0.14, relheight = 0.045, relx = x_en, rely = 0.66)
    type_c = ttk.Combobox(top,justify='center',textvariable=type_clicked,font=("TH Sarabun New",20), values = type_db )
    type_c.set(type_db[0])
    type_c.bind("<<ComboboxSelected>>", set_type)
    type_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.15, rely = 0.66)
    #detail รายละเอียด
    label(top,0.5,0.64,"รายละเอียด :")
    entry_detail = ttk.Entry(top,textvariable=detail,font=("TH Sarabun New",18,'bold'))
    entry_detail.place(relwidth = 0.4, relheight = 0.045, relx = x_en+0.4, rely = 0.66)
    #note หมายเหตุ
    label(top,0.5,0.78,"หมายเหตุ :")
    entry_note = ttk.Entry(top,textvariable=note,font=("TH Sarabun New",18,'bold'))
    entry_note.place(relwidth = 0.4,relheight = 0.045, relx = x_en+0.4, rely = 0.80)
    #namer ผู้ให้ข้อมูล 
    label(top,0.05,0.71,"ผู้ให้ข้อมูล :")
    entry_namer = ttk.Entry(top,textvariable=namer,font=("TH Sarabun New",18,'bold'))
    entry_namer.place(relwidth = 0.2, relheight = 0.045, relx = x_en-0.05, rely = 0.73)
    namer_c = ttk.Combobox(top,justify='center',textvariable=namer_clicked,font=("TH Sarabun New",20), values = namer_db )
    namer_c.set("ชื่อผู้ให้ข้อมูลทั้งหมด")
    namer_c.bind("<<ComboboxSelected>>", set_namer)
    namer_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.155, rely = 0.73)
    #namer_date ณ วันที่
    # label(top,0.5,0.71,"ณ วันที่ :")
    ttk.Label(top,text="ณ วันที่ :",font=("TH Sarabun New",18,'bold'),background=bg_frame).place(relx=0.5,rely=0.73)
    entry_namer_date = DateEntry(top,selectmode = 'day',textvariable=namer_date,font=("TH Sarabun New",18,'bold'))
    entry_namer_date.place(relwidth = 0.1, relheight = 0.045,relx = x_en+0.4, rely = 0.73)
    #owner ผู้รับผิดชอบ
    label(top,0.05,0.78,"ผู้รับผิดชอบ :")
    entry_owner = ttk.Entry(top,textvariable=owner,font=("TH Sarabun New",18,'bold'))
    entry_owner.place(relwidth = 0.2, relheight = 0.045, relx = x_en-0.05, rely = 0.80)
    owner_c = ttk.Combobox(top,justify='center',textvariable=owner_clicked,font=("TH Sarabun New",20), values = owner_db )
    owner_c.set("ชื่อผู้รับผิดชอบทั้งหมดทั้งหมด")
    owner_c.bind("<<ComboboxSelected>>", set_owner)
    owner_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.155, rely = 0.80)
    
    b = ttk.Button(top,text="เพิ่มข้อมูล",style='font_in.TButton',command=lambda:insert_data()).place(relwidth = 0.13, relheight = 0.075, relx = x_en+0.35, rely = 0.9)
    call_in_db_ = database_connector()
    def insert_data():
        id_value = id.get()
        namet_value = namet.get()
        year_value = ""
        band_value = band.get()
        model_value = model.get()
        serial_value = serial.get()
        price_value = price.get()
        datec_in = entry_datec.get_date()
        datec_value = datec_in.strftime("%d  %B  %Y")
        howc_value = howc.get()
        book_value = book.get()
        dateb_in = entry_dateb.get_date()
        dateb_value = dateb_in.strftime("%d  %B  %Y")
        type_thai_value = type_thai.get()
        subtype_thai_value = namet.get()
        subsubtype_value = subsubtype.get()
        type_value = type.get()
        datet_in = entry_datet.get_date()
        datet_value = datet_in.strftime("%d  %B  %Y")
        status1_value = status1.get()
        status2_value = status2.get()
        status3_value = status3.get()
        status4_value = status4.get()
        status5_value = status5.get()
        note_value = note.get()
        detail_value = detail.get()
        namer_value = namer.get()
        namer_date_in = entry_namer_date.get_date()
        namer_date_value = namer_date_in.strftime("%d  %B  %Y")
        owner_value = owner.get()
        room_value = room.get()
        for i in id_value.split('-') :
            if len(i)%2==0:
                year_value = i
                break
        
        if(id_value==""):
            MessageBox.showinfo("เพิ่มรหัสครุภัณฑ์","กรุณาใส่ข้อมูล",parent = top)
            return
        try :
            current_time = tm.strftime('%m/%d/%Y, %H:%M:%S:%p')
            call_in_db_.insert(id_value,namet_value,detail_value,band_value,model_value,serial_value,price_value,datec_value,howc_value,book_value,dateb_value,type_thai_value,subtype_thai_value,subsubtype_value,type_value,datet_value,status1_value,status2_value,status3_value,status4_value,status5_value,note_value,year_value,namer_value,namer_date_value,owner_value,room_value)
            ##########################
            call_in_db_.insert_history(id_value,current_time,"ใหม่",status3_value,note_value)
            set_zero()
            MessageBox.showinfo("เพิ่มรหัสครุภัณฑ์","เพิ่มข้อมูลสำเร็จ",parent = top)
            threading.Thread(target=search1(1)).start()
            all_year()
        except:
            set_zero()
            MessageBox.showinfo("เพิ่มรหัสครุภัณฑ์","มีข้อมูลนี้อยู่แล้ว",parent = top)

def insert_database_place():
    def set_zero():
        room.set("")
        name_place.set("")
        level1.set("")
        level1_name.set("")
        level2.set("")
        level2_name.set("")
        level3.set("")
        level3_name.set("")
        level4.set("")
        level4_name.set("")
        tel.set("")
    set_zero()
    top = Toplevel()
    top.geometry("1280x720")
    top.iconbitmap(photo_)
    top.title("เพิ่มห้อง")
    top.configure(bg=bg_frame)
    x_en = 0.185
    #StringVar()
    room_clicked = StringVar()
    level4_clicked = StringVar()
    level4_name_clicked = StringVar()
    level3_clicked = StringVar()
    level3_name_clicked = StringVar()
    level2_clicked = StringVar()
    level2_name_clicked = StringVar()
    level1_clicked = StringVar()
    level1_name_clicked = StringVar()
    #level1
    def set_level1_name(e):
        level1_name.set("")
        entry_level1_name.insert(0,level1_name_clicked.get())
    def set_level1(e):
        level1.set("")
        entry_level1.insert(0,level1_clicked.get())
    #level2
    def set_level2_name(e):
        level2_name.set("")
        entry_level2_name.insert(0,level2_name_clicked.get())
    def set_level2(e):
        level2.set("")
        entry_level2.insert(0,level2_clicked.get())
    #level3
    def set_level3_name(e):
        level3_name.set("")
        entry_level3_name.insert(0,level3_name_clicked.get())
    def set_level3(e):
        level3.set("")
        entry_level3.insert(0,level3_clicked.get())
    #level4
    def set_level4_name(e):
        level4_name.set("")
        entry_level4_name.insert(0,level4_name_clicked.get())
    def set_level4(e):
        level4.set("")
        entry_level4.insert(0,level4_clicked.get())
    def set_room(e):
        room.set("")
        entry_room.insert(0,room_clicked.get())
    def label(top,x,y,text):
        label = ttk.Label(top,text = text,font=("TH Sarabun New",20,'bold'),background=bg_frame)
        label.place(relwidth = 0.2, relheight = 0.1, relx = x, rely = y)
    #room รหัสห้อง
    label(top,0.04,0.03,"รหัสห้อง :")
    entry_room = ttk.Entry(top,textvariable= room,font=("TH Sarabun New",20,'bold'))
    entry_room.place(relwidth = 0.1, relheight = 0.045, relx = x_en-0.075, rely = 0.05)
    room_c = ttk.Combobox(top,justify='center',textvariable=room_clicked,font=("TH Sarabun New",20), values = id_room_p_db )
    room_c.set("รหัสห้องทั้งหมด")
    room_c.bind("<<ComboboxSelected>>", set_room)
    room_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.035, rely = 0.05)
    #name ชื่อห้อง
    label(top,0.35,0.03,"ชื่อห้อง :")
    entry_name = ttk.Entry(top,textvariable= name_place,font=("TH Sarabun New",20,'bold'))
    entry_name.place(relwidth = 0.15, relheight = 0.045, relx = x_en+0.25, rely = 0.05)
    #tel เบอร์ติดต่อ
    label(top,0.6,0.03,"เบอร์ติดต่อ :")
    entry_name = ttk.Entry(top,textvariable= tel,font=("TH Sarabun New",20,'bold'))
    entry_name.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.5, rely = 0.05)
    #level4 กอง/สำนัก
    label(top,0.04,0.11,"กอง/สำนัก :")
    entry_level4 = ttk.Entry(top,textvariable= level4,font=("TH Sarabun New",20,'bold'))
    entry_level4.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.05, rely = 0.13)
    level4_c = ttk.Combobox(top,justify='center',textvariable=level4_clicked,font=("TH Sarabun New",20), values = level4_p_db )
    level4_c.set(level4_p_db[0])
    level4_c.bind("<<ComboboxSelected>>", set_level4)
    level4_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.075, rely = 0.13)
    #level4_name 
    entry_level4_name = ttk.Entry(top,textvariable= level4_name,font=("TH Sarabun New",20,'bold'))
    entry_level4_name.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.2, rely = 0.13)
    level4_name_c = ttk.Combobox(top,justify='center',textvariable=level4_name_clicked,font=("TH Sarabun New",20), values = level4_name_p_db )
    level4_name_c.set(level4_name_p_db[0])
    level4_name_c.bind("<<ComboboxSelected>>", set_level4_name)
    level4_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.35, rely = 0.13)
    #level3
    entry_level3 = ttk.Entry(top,textvariable= level3,font=("TH Sarabun New",20,'bold'))
    entry_level3.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.21)
    level3_c = ttk.Combobox(top,justify='center',textvariable=level3_clicked,font=("TH Sarabun New",20), values = level3_p_db )
    level3_c.set(level3_p_db[0])
    level3_c.bind("<<ComboboxSelected>>", set_level3)
    level3_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.21)
    #level3_name
    entry_level3_name = ttk.Entry(top,textvariable= level3_name,font=("TH Sarabun New",20,'bold'))
    entry_level3_name.place(relwidth = 0.175, relheight = 0.045, relx = x_en+0.1, rely = 0.21)
    level3_name_c = ttk.Combobox(top,justify='center',textvariable=level3_name_clicked,font=("TH Sarabun New",20), values = level3_name_p_db )
    level3_name_c.set(level3_name_p_db[0])
    level3_name_c.bind("<<ComboboxSelected>>", set_level3_name)
    level3_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.285, rely = 0.21)

    #level2
    entry_level2 = ttk.Entry(top,textvariable= level2,font=("TH Sarabun New",20,'bold'))
    entry_level2.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.28)
    level2_c = ttk.Combobox(top,justify='center',textvariable=level2_clicked,font=("TH Sarabun New",20), values = level2_p_db )
    level2_c.set(level2_p_db[0])
    level2_c.bind("<<ComboboxSelected>>", set_level2)
    level2_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.28)
    #level2_name
    entry_level2_name = ttk.Entry(top,textvariable= level2_name,font=("TH Sarabun New",20,'bold'))
    entry_level2_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.1, rely = 0.28)
    level2_name_c = ttk.Combobox(top,justify='center',textvariable=level2_name_clicked,font=("TH Sarabun New",20), values = level2_name_p_db )
    level2_name_c.set(level2_name_p_db[0])
    level2_name_c.bind("<<ComboboxSelected>>", set_level2_name)
    level2_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.415, rely = 0.28)

    #level1
    entry_level1 = ttk.Entry(top,textvariable= level1,font=("TH Sarabun New",20,'bold'))
    entry_level1.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.35)
    level1_c = ttk.Combobox(top,justify='center',textvariable=level1_clicked,font=("TH Sarabun New",20), values = level1_p_db )
    level1_c.set(level1_p_db[0])
    level1_c.bind("<<ComboboxSelected>>", set_level1)
    level1_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.35)
    #level1_name
    entry_level1_name = ttk.Entry(top,textvariable= level1_name,font=("TH Sarabun New",20,'bold'))
    entry_level1_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.1, rely = 0.35)
    level1_name_c = ttk.Combobox(top,justify='center',textvariable=level1_name_clicked,font=("TH Sarabun New",35), values = level1_name_p_db )
    level1_name_c.set(level1_name_p_db[0])
    level1_name_c.bind("<<ComboboxSelected>>", set_level1_name)
    level1_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.415, rely = 0.35)

    b = ttk.Button(top,text="เพิ่มข้อมูล",style='font_in.TButton',command=lambda:insert_data()).place(relwidth = 0.13, relheight = 0.075, relx = x_en+0.65, rely = 0.85)
    call_in_db_ = database_connector()
    def insert_data():
        room_value = room.get()
        name_place_value = name_place.get()
        tel_value = tel.get()
        level1_value = level1.get()
        level1_name_value = level1_name.get()
        level2_value = level2.get()
        level2_name_value = level2_name.get()
        level3_value = level3.get()
        level3_name_value = level3_name.get()
        level4_value = level4.get()
        level4_name_value = level4_name.get()
        if(room_value==""):
            MessageBox.showinfo("เพิ่มห้อง","กรุณาใส่ข้อมูล",parent = top)
            return
        try :
            call_in_db_.insert_place(room_value,name_place_value,tel_value,level1_value,level1_name_value,level2_value,level2_name_value,level3_value,level3_name_value,level4_value,level4_name_value)
            set_zero()
            MessageBox.showinfo("เพิ่มห้อง","เพิ่มข้อมูลสำเร็จ",parent = top)
        except:
            set_zero()
            MessageBox.showinfo("เพิ่มห้อง","มีข้อมูลนี้อยู่แล้ว",parent = top)

def insert_database_owner():
    def set_zero():
        font_name.set("")
        name_font.set("")
        name_last.set("")
        post.set("")
        olevel.set("")
        oroom.set("")
        oroom_name.set("")
        otel.set("")
        olevel1.set("")
        olevel1_name.set("")
        olevel2.set("")
        olevel2_name.set("")
        olevel3.set("")
        olevel3_name.set("")
        olevel4.set("")
        olevel4_name.set("")
        wrooom.set("")
        wroom_name.set("")
        wtel.set("")
        wlevel1.set("")
        wlevel1_name.set("")
        wlevel2.set("")
        wlevel2_name.set("")
        wlevel3.set("")
        wlevel3_name.set("")
        wlevel4.set("")
        wlevel4_name.set("")
    set_zero()
    top = Toplevel()
    top.geometry("1280x720")
    top.iconbitmap(photo_)
    top.title("เพิ่มผู้ดูแล")
    top.configure(bg=bg_frame)
    x_en = 0.185
    #StringVar()
    font_name_clicked = StringVar()
    post_clicked = StringVar()
    olevel_clicked = StringVar()
    oroom_clicked = StringVar()
    olevel4_clicked = StringVar()
    olevel4_name_clicked = StringVar()
    olevel3_clicked = StringVar()
    olevel3_name_clicked = StringVar()
    olevel2_clicked = StringVar()
    olevel2_name_clicked = StringVar()
    olevel1_clicked = StringVar()
    olevel1_name_clicked = StringVar()
    wroom_clicked = StringVar()
    wlevel4_clicked = StringVar()
    wlevel4_name_clicked = StringVar()
    wlevel3_clicked = StringVar()
    wlevel3_name_clicked = StringVar()
    wlevel2_clicked = StringVar()
    wlevel2_name_clicked = StringVar()
    wlevel1_clicked = StringVar()
    wlevel1_name_clicked = StringVar()
    def label(top,x,y,text):
        label = ttk.Label(top,text = text,font=("TH Sarabun New",20,'bold'),background=bg_frame)
        label.place(relwidth = 0.20, relx = x, rely = y)
    def set_font_name(e):
        font_name.set("")
        entry_font_name.insert(0,font_name_clicked.get())
    def set_post(e):
        post.set("")
        entry_post.insert(0,post_clicked.get())
    def set_olevel(e):
        olevel.set("")
        entry_olevel.insert(0,olevel_clicked.get())
    def set_oroom(e):
        oroom.set("")
        entry_oroom.insert(0,oroom_clicked.get())
    def set_olevel4(e):
        olevel4.set("")
        entry_olevel4.insert(0,olevel4_clicked.get())
    def set_olevel4_name(e):
        olevel4_name.set("")
        entry_olevel4_name.insert(0,olevel4_name_clicked.get())
    def set_olevel3(e):
        olevel3.set("")
        entry_olevel3.insert(0,olevel3_clicked.get())
    def set_olevel3_name(e):
        olevel3_name.set("")
        entry_olevel3_name.insert(0,olevel3_name_clicked.get())
    def set_olevel2(e):
        olevel2.set("")
        entry_olevel2.insert(0,olevel2_clicked.get())
    def set_olevel2_name(e):
        olevel2_name.set("")
        entry_olevel2_name.insert(0,olevel2_name_clicked.get())
    def set_olevel1(e):
        olevel1.set("")
        entry_olevel1.insert(0,olevel1_clicked.get())
    def set_olevel1_name(e):
        olevel1_name.set("")
        entry_olevel1_name.insert(0,olevel1_name_clicked.get())
    ###########
    def set_wrooom(e):
        wrooom.set("")
        entry_wrooom.insert(0,wroom_clicked.get())
    def set_wlevel4(e):
        wlevel4.set("")
        entry_wlevel4.insert(0,wlevel4_clicked.get())
    def set_wlevel4_name(e):
        wlevel4_name.set("")
        entry_wlevel4_name.insert(0,wlevel4_name_clicked.get())
    def set_wlevel3(e):
        wlevel3.set("")
        entry_wlevel3.insert(0,wlevel3_clicked.get())
    def set_wlevel3_name(e):
        wlevel3_name.set("")
        entry_wlevel3_name.insert(0,wlevel3_name_clicked.get())
    def set_wlevel2(e):
        wlevel2.set("")
        entry_wlevel2.insert(0,wlevel2_clicked.get())
    def set_wlevel2_name(e):
        wlevel2_name.set("")
        entry_wlevel2_name.insert(0,wlevel2_name_clicked.get())
    def set_wlevel1(e):
        wlevel1.set("")
        entry_wlevel1.insert(0,wlevel1_clicked.get())
    def set_wlevel1_name(e):
        wlevel1_name.set("")
        entry_wlevel1_name.insert(0,wlevel1_name_clicked.get())
    #font_name คำนำหน้าชื่อ
    label(top,0.04,0.05,"ชื่อ-นามสกุล :")
    entry_font_name = ttk.Entry(top,textvariable= font_name,font=("TH Sarabun New",20,'bold'))
    entry_font_name.place(relwidth = 0.155, relheight = 0.045, relx = x_en-0.05, rely = 0.05)
    font_name_c = ttk.Combobox(top,justify='center',textvariable=font_name_clicked,font=("TH Sarabun New",18), values = font_name_db)
    font_name_c.set(font_name_db[0])
    font_name_c.bind("<<ComboboxSelected>>", set_font_name)
    font_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.115, rely = 0.05)
    #name_owner ชื่อ
    entry_name_font = ttk.Entry(top,textvariable= name_font ,font=("TH Sarabun New",20,'bold'))
    entry_name_font.place(relwidth = 0.155, relheight = 0.045, relx = x_en+0.24, rely = 0.05)
    entry_name_last = ttk.Entry(top,textvariable= name_last ,font=("TH Sarabun New",20,'bold'))
    entry_name_last.place(relwidth = 0.155, relheight = 0.045, relx = x_en+0.4, rely = 0.05)
    #post ตำแหน่ง
    label(top,0.04,0.11,"ตำแหน่ง :")
    entry_post = ttk.Entry(top,textvariable= post,font=("TH Sarabun New",20,'bold'))
    entry_post.place(relwidth = 0.23, relheight = 0.045, relx = x_en-0.075, rely = 0.11)
    post_c = ttk.Combobox(top,justify='center',textvariable=post_clicked,font=("TH Sarabun New",18), values = post_db)
    post_c.set(post_db[0])
    post_c.bind("<<ComboboxSelected>>", set_post)
    post_c.place(relwidth = 0.135, relheight = 0.045, relx = x_en+0.165, rely = 0.11)
    #olevel ระดับ
    label(top,0.49,0.11,"ระดับ :")
    entry_olevel = ttk.Entry(top,textvariable= olevel,font=("TH Sarabun New",20,'bold'))
    entry_olevel.place(relwidth = 0.15, relheight = 0.045, relx = x_en+0.355, rely = 0.11)
    olevel_c = ttk.Combobox(top,justify='center',textvariable=olevel_clicked,font=("TH Sarabun New",18), values = olevel_db)
    olevel_c.set(olevel_db[0])
    olevel_c.bind("<<ComboboxSelected>>", set_olevel)
    olevel_c.place(relwidth = 0.135, relheight = 0.045, relx = x_en+0.525, rely = 0.11)
    #oroom รหัสห้อง
    label(top,0.04,0.17,"รหัสห้อง :")
    entry_oroom = ttk.Entry(top,textvariable= oroom,font=("TH Sarabun New",20,'bold'))
    entry_oroom.place(relwidth = 0.1, relheight = 0.045, relx = x_en-0.075, rely = 0.17)
    oroom_c = ttk.Combobox(top,textvariable= oroom_clicked,font=("TH Sarabun New",18,'bold'),values = oroom_db)
    oroom_c.set(oroom_db[0])
    oroom_c.bind("<<ComboboxSelected>>", set_oroom)
    oroom_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.03, rely = 0.17)
    #oroom_name ชื่อห้อง
    label(top,0.35,0.17,"ชื่อห้อง :")
    entry_oroom_name = ttk.Entry(top,textvariable= oroom_name,font=("TH Sarabun New",20,'bold'))
    entry_oroom_name.place(relwidth = 0.15, relheight = 0.045, relx = x_en+0.25, rely = 0.17)
    #otel เบอร์ติดต่อ
    label(top,0.6,0.17,"เบอร์ติดต่อ :")
    entry_otel = ttk.Entry(top,textvariable= otel,font=("TH Sarabun New",20,'bold'))
    entry_otel.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.5, rely = 0.17)
    #level4 กอง/สำนัก
    label(top,0.04,0.24,"กอง/สำนัก :")
    entry_olevel4 = ttk.Entry(top,textvariable= olevel4,font=("TH Sarabun New",20,'bold'))
    entry_olevel4.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.05, rely = 0.24)
    olevel4_c = ttk.Combobox(top,justify='center',textvariable=olevel4_clicked,font=("TH Sarabun New",18), values = olevel4_db )
    olevel4_c.set(olevel4_db[0])
    olevel4_c.bind("<<ComboboxSelected>>", set_olevel4)
    olevel4_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.075, rely = 0.24)
    #olevel4_name 
    entry_olevel4_name = ttk.Entry(top,textvariable= olevel4_name,font=("TH Sarabun New",20,'bold'))
    entry_olevel4_name.place(relwidth = 0.25, relheight = 0.045, relx = x_en+0.2, rely = 0.24)
    olevel4_name_c = ttk.Combobox(top,justify='center',textvariable=olevel4_name_clicked,font=("TH Sarabun New",18), values = olevel4_name_db )
    olevel4_name_c.set(olevel4_name_db[0])
    olevel4_name_c.bind("<<ComboboxSelected>>", set_olevel4_name)
    olevel4_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.475, rely = 0.24)
    #olevel3
    entry_olevel3 = ttk.Entry(top,textvariable= olevel3,font=("TH Sarabun New",20,'bold'))
    entry_olevel3.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.30)
    olevel3_c = ttk.Combobox(top,justify='center',textvariable=olevel3_clicked,font=("TH Sarabun New",18), values = olevel3_db )
    olevel3_c.set(olevel3_db[0])
    olevel3_c.bind("<<ComboboxSelected>>", set_olevel3)
    olevel3_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.30)
    #olevel3_name
    entry_olevel3_name = ttk.Entry(top,textvariable= olevel3_name,font=("TH Sarabun New",20,'bold'))
    entry_olevel3_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.1, rely = 0.30)
    olevel3_name_c = ttk.Combobox(top,justify='center',textvariable=olevel3_name_clicked,font=("TH Sarabun New",18), values = olevel3_name_db )
    olevel3_name_c.set(olevel3_name_db[0])
    olevel3_name_c.bind("<<ComboboxSelected>>", set_olevel3_name)
    olevel3_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.415, rely = 0.30)

    #olevel2
    entry_olevel2 = ttk.Entry(top,textvariable= olevel2,font=("TH Sarabun New",20,'bold'))
    entry_olevel2.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.36)
    olevel2_c = ttk.Combobox(top,justify='center',textvariable=olevel2_clicked,font=("TH Sarabun New",18), values = olevel2_db )
    olevel2_c.set(olevel2_db[0])
    olevel2_c.bind("<<ComboboxSelected>>", set_olevel2)
    olevel2_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.36)
    #olevel2_name
    entry_olevel2_name = ttk.Entry(top,textvariable= olevel2_name,font=("TH Sarabun New",20,'bold'))
    entry_olevel2_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.1, rely = 0.36)
    olevel2_name_c = ttk.Combobox(top,justify='center',textvariable=olevel2_name_clicked,font=("TH Sarabun New",18), values = olevel2_name_db )
    olevel2_name_c.set(olevel2_name_db[0])
    olevel2_name_c.bind("<<ComboboxSelected>>", set_olevel2_name)
    olevel2_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.415, rely = 0.36)

    #olevel1
    entry_olevel1 = ttk.Entry(top,textvariable= olevel1,font=("TH Sarabun New",20,'bold'))
    entry_olevel1.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.42)
    olevel1_c = ttk.Combobox(top,justify='center',textvariable=olevel1_clicked,font=("TH Sarabun New",18), values = olevel1_db )
    olevel1_c.set(olevel1_db[0])
    olevel1_c.bind("<<ComboboxSelected>>", set_olevel1)
    olevel1_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.42)
    #olevel1_name
    entry_olevel1_name = ttk.Entry(top,textvariable= olevel1_name,font=("TH Sarabun New",20,'bold'))
    entry_olevel1_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.1, rely = 0.42)
    olevel1_name_c = ttk.Combobox(top,justify='center',textvariable=olevel1_name_clicked,font=("TH Sarabun New",18), values = olevel1_name_db )
    olevel1_name_c.set(olevel1_name_db[0])
    olevel1_name_c.bind("<<ComboboxSelected>>", set_olevel1_name)
    olevel1_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.415, rely = 0.42)
    #หน่วยงานผู้รับผิดชอบครุภัณฑ์
    l1 = Label(top,text="หน่วยงานผู้รับผิดชอบครุภัณฑ์",font=("TH Sarabun New",24,'bold'),background=bg_frame)
    l1.place(relx=0.4,rely=0.48)
    #wrooom รหัสห้อง
    label(top,0.04,0.54,"รหัสห้อง :")
    entry_wrooom = ttk.Entry(top,textvariable= wrooom,font=("TH Sarabun New",20,'bold'))
    entry_wrooom.place(relwidth = 0.1, relheight = 0.045, relx = x_en-0.075, rely = 0.54)
    wrooom_c = ttk.Combobox(top,textvariable= wroom_clicked,font=("TH Sarabun New",18,'bold'),values = wrooom_db)
    wrooom_c.set(wrooom_db[0])
    wrooom_c.bind("<<ComboboxSelected>>", set_wrooom)
    wrooom_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.03, rely = 0.54)
    #wroom_name ชื่อห้อง
    label(top,0.35,0.54,"ชื่อห้อง :")
    entry_oroom_name = ttk.Entry(top,textvariable= wroom_name,font=("TH Sarabun New",20,'bold'))
    entry_oroom_name.place(relwidth = 0.15, relheight = 0.045, relx = x_en+0.25, rely = 0.54)
    #wtel เบอร์ติดต่อ
    label(top,0.6,0.54,"เบอร์ติดต่อ :")
    entry_otel = ttk.Entry(top,textvariable= wtel,font=("TH Sarabun New",20,'bold'))
    entry_otel.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.5, rely = 0.54)
    #wlevel4 กอง/สำนัก
    label(top,0.04,0.60,"กอง/สำนัก :")
    entry_wlevel4 = ttk.Entry(top,textvariable= wlevel4,font=("TH Sarabun New",20,'bold'))
    entry_wlevel4.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.05, rely = 0.60)
    wlevel4_c = ttk.Combobox(top,justify='center',textvariable=wlevel4_clicked,font=("TH Sarabun New",18), values = wlevel4_db )
    wlevel4_c.set(wlevel4_db[0])
    wlevel4_c.bind("<<ComboboxSelected>>", set_wlevel4)
    wlevel4_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.075, rely = 0.60)
    #wlevel4_name 
    entry_wlevel4_name = ttk.Entry(top,textvariable= wlevel4_name,font=("TH Sarabun New",20,'bold'))
    entry_wlevel4_name.place(relwidth = 0.25, relheight = 0.045, relx = x_en+0.2, rely = 0.60)
    wlevel4_name_c = ttk.Combobox(top,justify='center',textvariable=wlevel4_name_clicked,font=("TH Sarabun New",18), values = wlevel4_name_db )
    wlevel4_name_c.set(wlevel4_name_db[0])
    wlevel4_name_c.bind("<<ComboboxSelected>>", set_wlevel4_name)
    wlevel4_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.475, rely = 0.60)
    #wlevel3
    entry_wlevel3 = ttk.Entry(top,textvariable= wlevel3,font=("TH Sarabun New",20,'bold'))
    entry_wlevel3.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.66)
    wlevel3_c = ttk.Combobox(top,justify='center',textvariable=wlevel3_clicked,font=("TH Sarabun New",18), values = wlevel3_db )
    wlevel3_c.set(wlevel3_db[0])
    wlevel3_c.bind("<<ComboboxSelected>>", set_wlevel3)
    wlevel3_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.66)
    #wlevel3_name
    entry_wlevel3_name = ttk.Entry(top,textvariable= wlevel3_name,font=("TH Sarabun New",20,'bold'))
    entry_wlevel3_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.1, rely = 0.66)
    wlevel3_name_c = ttk.Combobox(top,justify='center',textvariable=wlevel3_name_clicked,font=("TH Sarabun New",18), values = wlevel3_name_db )
    wlevel3_name_c.set(olevel3_name_db[0])
    wlevel3_name_c.bind("<<ComboboxSelected>>", set_wlevel3_name)
    wlevel3_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.415, rely = 0.66)

    #wlevel2
    entry_wlevel2 = ttk.Entry(top,textvariable= wlevel2,font=("TH Sarabun New",20,'bold'))
    entry_wlevel2.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.72)
    wlevel2_c = ttk.Combobox(top,justify='center',textvariable=wlevel2_clicked,font=("TH Sarabun New",18), values = wlevel2_db )
    wlevel2_c.set(wlevel2_db[0])
    wlevel2_c.bind("<<ComboboxSelected>>", set_wlevel2)
    wlevel2_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.72)
    #wlevel2_name
    entry_wlevel2_name = ttk.Entry(top,textvariable= wlevel2_name,font=("TH Sarabun New",20,'bold'))
    entry_wlevel2_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.1, rely = 0.72)
    wlevel2_name_c = ttk.Combobox(top,justify='center',textvariable=wlevel2_name_clicked,font=("TH Sarabun New",18), values = wlevel2_name_db )
    wlevel2_name_c.set(wlevel2_name_db[0])
    wlevel2_name_c.bind("<<ComboboxSelected>>", set_wlevel2_name)
    wlevel2_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.415, rely = 0.72)

    #wlevel1
    entry_wlevel1 = ttk.Entry(top,textvariable= wlevel1,font=("TH Sarabun New",20,'bold'))
    entry_wlevel1.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.78)
    wlevel1_c = ttk.Combobox(top,justify='center',textvariable=wlevel1_clicked,font=("TH Sarabun New",18), values = wlevel1_db )
    wlevel1_c.set(wlevel1_db[0])
    wlevel1_c.bind("<<ComboboxSelected>>", set_wlevel1)
    wlevel1_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.78)
    #wlevel1_name
    entry_wlevel1_name = ttk.Entry(top,textvariable= wlevel1_name,font=("TH Sarabun New",20,'bold'))
    entry_wlevel1_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.1, rely = 0.78)
    wlevel1_name_c = ttk.Combobox(top,justify='center',textvariable=wlevel1_name_clicked,font=("TH Sarabun New",18), values = wlevel1_name_db )
    wlevel1_name_c.set(wlevel1_name_db[0])
    wlevel1_name_c.bind("<<ComboboxSelected>>", set_wlevel1_name)
    wlevel1_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.415, rely = 0.78)

    b = ttk.Button(top,text="เพิ่มข้อมูล",style='font_in.TButton',command=lambda:insert_data()).place(relwidth = 0.13, relheight = 0.075, relx = x_en+0.65, rely = 0.85)
    call_in_db_ = database_connector()
    def insert_data():
        font_name_value = font_name.get()
        name_font_value = name_font.get()
        name_last_value = name_last.get()
        name_owner = name_font_value+" "+name_last_value
        post_value = post.get()
        olevel_value = olevel.get()
        oroom_value = oroom.get()
        oroom_name_value = oroom_name.get()
        otel_value = otel.get()
        olevel4_value = olevel4.get()
        olevel4_name_value = olevel4_name.get()
        olevel3_value = olevel3.get()
        olevel3_name_value = olevel3_name.get()
        olevel2_value = olevel2.get()
        olevel2_name_value = olevel2_name.get()
        olevel1_value = olevel1.get()
        olevel1_name_value = olevel1_name.get()
        wrooom_value = wrooom.get()
        wroom_name_value = wroom_name.get()
        wtel_value = wtel.get()
        wlevel1_value = wlevel1.get()
        wlevel1_name_value = wlevel1_name.get()
        wlevel2_value = wlevel2.get()
        wlevel2_name_value = wlevel2_name.get()
        wlevel3_value = wlevel3.get()
        wlevel3_name_value = wlevel3_name.get()
        wlevel4_value = wlevel4.get()
        wlevel4_name_value = wlevel4_name.get()
        if(name_font_value=="" and name_last_value==""):
            MessageBox.showinfo("เพิ่มผู้ดูแล","กรุณาใส่ข้อมูล",parent = top)
            return
        try :
            call_in_db_.insert_owner(font_name_value,name_owner,post_value,olevel_value,oroom_value,oroom_name_value,otel_value,olevel1_value,olevel1_name_value,olevel2_value,olevel2_name_value,olevel3_value,olevel3_name_value,olevel4_value,olevel4_name_value,wrooom_value,wroom_name_value,wtel_value,wlevel1_value,wlevel1_name_value,wlevel2_value,wlevel2_name_value,wlevel3_value,wlevel3_name_value,wlevel4_value,wlevel4_name_value)
            set_zero()
            MessageBox.showinfo("เพิ่มผู้ดูแล","เพิ่มข้อมูลสำเร็จ",parent = top)
        except:
            set_zero()
            MessageBox.showinfo("เพิ่มผู้ดูแล","มีข้อมูลนี้อยู่แล้ว",parent = top)
def delete_place():
    room.set("")
    top = Toplevel()
    top.geometry("500x240+150+150")
    top.iconbitmap(photo_)
    top.title("ลบห้อง")
    top.configure(bg = bg_frame)
    temp = database_connector()
    x_en = 0.45
    room_clicked = StringVar()
    def set_room(e):
        room.set("")
        entry_room.insert(0,room_clicked.get())
    def label(top,x,y,text):
        label = ttk.Label(top,text = text,font=("TH Sarabun New",20,'bold'),background=bg_frame)
        label.place(relwidth = 0.3, relheight = 0.15, relx = x, rely = y)
    def ask():
        return MessageBox.askyesno("ลบข้อมูล", "ต้องการลบห้อง : "+room.get()+" ?",parent = top)
    def delete_():
        room_value = room.get()
        if(room_value ==""):
            MessageBox.showinfo("ลบข้อมูล","กรุณาใส่ผู้ดูแล",parent = top)
            return
        if ask():
            try :
                temp.delete_place(room_value)
                MessageBox.showinfo("ลบข้อมูล","ลบข้อมูลแล้ว "+room_value,parent = top)
                room.set("")
            except:
                room.set("")
                MessageBox.showinfo("ลบข้อมูล","ไม่พบข้อมูลที่จะลบ",icon ='error',parent = top)
        else :
            return
    label(top,0.1,0.1,"รหัสห้อง :")
    entry_room = ttk.Entry(top,textvariable= room,font=("TH Sarabun New",20,'bold'))
    entry_room.place( relwidth=0.25,relx = x_en-0.1, rely = 0.1)
    room_c = ttk.Combobox(top,justify='center',textvariable=room_clicked,font=("TH Sarabun New",20), values = id_room_p_db )
    room_c.set("รหัสห้องทั้งหมด")
    room_c.bind("<<ComboboxSelected>>", set_room)
    room_c.place(relwidth=0.25,relx = x_en+0.185, rely = 0.1)
    b = ttk.Button(top,text="ลบข้อมูล",style='font_in.TButton',command=lambda:delete_()).place(relwidth = 0.2, relheight = 0.175, relx = 0.71, rely = 0.75)
def delete_owner():
    name_full.set("")
    top = Toplevel()
    top.geometry("500x240+500+300")
    top.iconbitmap(photo_)
    top.title("ลบผู้ดูแล")
    top.configure(bg = bg_frame)
    temp = database_connector()
    x_en = 0.45
    def label(top,x,y,text):
        label = ttk.Label(top,text = text,font=("TH Sarabun New",20,'bold'),background=bg_frame)
        label.place(relwidth = 0.3, relheight = 0.15, relx = x, rely = y)
    label(top,0.1,0.1,"ผู้ดูแล :")
    def ask():
        return MessageBox.askyesno("ลบข้อมูล", "ต้องการลบผู้ดูแล : "+id.get()+" ?",parent = top)
    def delete_():
        name_full_value = name_full.get()
        if(name_full_value ==""):
            MessageBox.showinfo("ลบข้อมูล","กรุณาใส่ผู้ดูแล",parent = top)
            return
        if ask():
            try :
                temp.delete_owner(name_full_value)
                MessageBox.showinfo("ลบข้อมูล","ลบข้อมูลแล้ว "+name_full_value,parent = top)
                name_full.set("")
            except:
                name_full.set("")
                MessageBox.showinfo("ลบข้อมูล","ไม่พบข้อมูลที่จะลบ",icon ='error',parent = top)
        else :
            return
    entry_name = ttk.Entry(top,textvariable=name_full,font=("TH Sarabun New",20,'bold')).place(relwidth = 0.3, relheight = 0.115, relx = x_en, rely = 0.12)
    b = ttk.Button(top,text="ลบข้อมูล",style='font_in.TButton',command=lambda:delete_()).place(relwidth = 0.2, relheight = 0.175, relx = 0.71, rely = 0.75)
def get_detail_owner():
    def set_zero():
        name_full.set("")
        font_name.set("")
        name_font.set("")
        name_last.set("")
        post.set("")
        olevel.set("")
        oroom.set("")
        oroom_name.set("")
        otel.set("")
        olevel1.set("")
        olevel1_name.set("")
        olevel2.set("")
        olevel2_name.set("")
        olevel3.set("")
        olevel3_name.set("")
        olevel4.set("")
        olevel4_name.set("")
        wrooom.set("")
        wroom_name.set("")
        wtel.set("")
        wlevel1.set("")
        wlevel1_name.set("")
        wlevel2.set("")
        wlevel2_name.set("")
        wlevel3.set("")
        wlevel3_name.set("")
        wlevel4.set("")
        wlevel4_name.set("")
    set_zero()
    top = Toplevel()
    top.geometry("1280x720")
    top.iconbitmap(photo_)
    top.title("รายละเอียดผู้ดูแล")
    top.configure(bg=bg_frame)
    x_en = 0.185
    #StringVar()
    name_clicked = StringVar()
    def set_name(e):
        name_full.set("")
        entry_name.insert(0,name_clicked.get())
    def label(top,x,y,text):
        label = ttk.Label(top,text = text,font=("TH Sarabun New",20,'bold'),background=bg_frame)
        label.place(relwidth = 0.20, relx = x, rely = y)
    #font_name คำนำหน้าชื่อ
    label(top,0.04,0.05,"ชื่อ-นามสกุล :")
    #name_owner ชื่อ
    entry_name = ttk.Entry(top,textvariable=name_full ,font=("TH Sarabun New",20,'bold'))
    entry_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en-0.05, rely = 0.05)
    name_c = ttk.Combobox(top,textvariable= name_clicked,font=("TH Sarabun New",18,'bold'),values = name_owner_db)
    name_c.set(name_owner_db[0])
    name_c.bind("<<ComboboxSelected>>", set_name)
    name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.35, rely = 0.05)
    #post ตำแหน่ง
    label(top,0.04,0.11,"ตำแหน่ง :")
    entry_post = ttk.Entry(top,textvariable= post,font=("TH Sarabun New",20,'bold'))
    entry_post.place(relwidth = 0.23, relheight = 0.045, relx = x_en-0.075, rely = 0.11)
    #olevel ระดับ
    label(top,0.49,0.11,"ระดับ :")
    entry_olevel = ttk.Entry(top,textvariable= olevel,font=("TH Sarabun New",20,'bold'))
    entry_olevel.place(relwidth = 0.15, relheight = 0.045, relx = x_en+0.355, rely = 0.11)
    #oroom รหัสห้อง
    label(top,0.04,0.17,"รหัสห้อง :")
    entry_oroom = ttk.Entry(top,textvariable= oroom,font=("TH Sarabun New",20,'bold'))
    entry_oroom.place(relwidth = 0.1, relheight = 0.045, relx = x_en-0.075, rely = 0.17)
    #oroom_name ชื่อห้อง
    label(top,0.35,0.17,"ชื่อห้อง :")
    entry_oroom_name = ttk.Entry(top,textvariable= oroom_name,font=("TH Sarabun New",20,'bold'))
    entry_oroom_name.place(relwidth = 0.15, relheight = 0.045, relx = x_en+0.25, rely = 0.17)
    #otel เบอร์ติดต่อ
    label(top,0.6,0.17,"เบอร์ติดต่อ :")
    entry_otel = ttk.Entry(top,textvariable= otel,font=("TH Sarabun New",20,'bold'))
    entry_otel.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.5, rely = 0.17)
    #level4 กอง/สำนัก
    label(top,0.04,0.24,"กอง/สำนัก :")
    entry_olevel4 = ttk.Entry(top,textvariable= olevel4,font=("TH Sarabun New",20,'bold'))
    entry_olevel4.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.05, rely = 0.24)
    #olevel4_name 
    entry_olevel4_name = ttk.Entry(top,textvariable= olevel4_name,font=("TH Sarabun New",20,'bold'))
    entry_olevel4_name.place(relwidth = 0.25, relheight = 0.045, relx = x_en+0.1, rely = 0.24)
    #olevel3
    entry_olevel3 = ttk.Entry(top,textvariable= olevel3,font=("TH Sarabun New",20,'bold'))
    entry_olevel3.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.30)
    #olevel3_name
    entry_olevel3_name = ttk.Entry(top,textvariable= olevel3_name,font=("TH Sarabun New",20,'bold'))
    entry_olevel3_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en, rely = 0.30)
    #olevel2
    entry_olevel2 = ttk.Entry(top,textvariable= olevel2,font=("TH Sarabun New",20,'bold'))
    entry_olevel2.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.36)
    #olevel2_name
    entry_olevel2_name = ttk.Entry(top,textvariable= olevel2_name,font=("TH Sarabun New",20,'bold'))
    entry_olevel2_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en, rely = 0.36)
    #olevel1
    entry_olevel1 = ttk.Entry(top,textvariable= olevel1,font=("TH Sarabun New",20,'bold'))
    entry_olevel1.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.42)
    #olevel1_name
    entry_olevel1_name = ttk.Entry(top,textvariable= olevel1_name,font=("TH Sarabun New",20,'bold'))
    entry_olevel1_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en, rely = 0.42)
    #หน่วยงานผู้รับผิดชอบครุภัณฑ์
    l1 = Label(top,text="หน่วยงานผู้รับผิดชอบครุภัณฑ์",font=("TH Sarabun New",24,'bold'),background=bg_frame)
    l1.place(relx=0.4,rely=0.47)
    #wrooom รหัสห้อง
    label(top,0.04,0.54,"รหัสห้อง :")
    entry_wrooom = ttk.Entry(top,textvariable= wrooom,font=("TH Sarabun New",20,'bold'))
    entry_wrooom.place(relwidth = 0.1, relheight = 0.045, relx = x_en-0.075, rely = 0.54)
    #wroom_name ชื่อห้อง
    label(top,0.35,0.54,"ชื่อห้อง :")
    entry_oroom_name = ttk.Entry(top,textvariable= wroom_name,font=("TH Sarabun New",20,'bold'))
    entry_oroom_name.place(relwidth = 0.15, relheight = 0.045, relx = x_en+0.25, rely = 0.54)
    #wtel เบอร์ติดต่อ
    label(top,0.6,0.54,"เบอร์ติดต่อ :")
    entry_otel = ttk.Entry(top,textvariable= wtel,font=("TH Sarabun New",20,'bold'))
    entry_otel.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.5, rely = 0.54)
    #wlevel4 กอง/สำนัก
    label(top,0.04,0.60,"กอง/สำนัก :")
    entry_wlevel4 = ttk.Entry(top,textvariable= wlevel4,font=("TH Sarabun New",20,'bold'))
    entry_wlevel4.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.05, rely = 0.60)
    #wlevel4_name 
    entry_wlevel4_name = ttk.Entry(top,textvariable= wlevel4_name,font=("TH Sarabun New",20,'bold'))
    entry_wlevel4_name.place(relwidth = 0.25, relheight = 0.045, relx = x_en+0.1, rely = 0.60)
    #wlevel3
    entry_wlevel3 = ttk.Entry(top,textvariable= wlevel3,font=("TH Sarabun New",20,'bold'))
    entry_wlevel3.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.66)
    #wlevel3_name
    entry_wlevel3_name = ttk.Entry(top,textvariable= wlevel3_name,font=("TH Sarabun New",20,'bold'))
    entry_wlevel3_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en, rely = 0.66)
    #wlevel2
    entry_wlevel2 = ttk.Entry(top,textvariable= wlevel2,font=("TH Sarabun New",20,'bold'))
    entry_wlevel2.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.72)
    #wlevel2_name
    entry_wlevel2_name = ttk.Entry(top,textvariable= wlevel2_name,font=("TH Sarabun New",20,'bold'))
    entry_wlevel2_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en, rely = 0.72)
    #wlevel1
    entry_wlevel1 = ttk.Entry(top,textvariable= wlevel1,font=("TH Sarabun New",20,'bold'))
    entry_wlevel1.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.78)
    #wlevel1_name
    entry_wlevel1_name = ttk.Entry(top,textvariable= wlevel1_name,font=("TH Sarabun New",20,'bold'))
    entry_wlevel1_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en, rely = 0.78)
    def search_id_up():
        temp = search_in_db()
        name_value = name_full.get()
        if(name_value ==""):
            MessageBox.showinfo("ห้อง","กรุณาใส่รหัสห้อง",parent = top)
            return
        try:
            rows = temp.get_db_owner(name_value)
            if rows[0]!= NULL:
                for i in rows:
                    name_full.set(i[0]+i[1])
                    post.set(i[2])
                    olevel.set(i[3])
                    oroom.set(i[4])
                    oroom_name.set(i[5])
                    otel.set(i[6])
                    olevel1.set(i[7])
                    olevel1_name.set(i[8])
                    olevel2.set(i[9])
                    olevel2_name.set(i[10])
                    olevel3.set(i[11])
                    olevel3_name.set(i[12])
                    olevel4.set(i[13])
                    olevel4_name.set(i[14])
                    wrooom.set(i[15])
                    wroom_name.set(i[16])
                    wtel.set(i[17])
                    wlevel1.set(i[18])
                    wlevel1_name.set(i[19])
                    wlevel2.set(i[20])
                    wlevel2_name.set(i[21])
                    wlevel3.set(i[22])
                    wlevel3_name.set(i[23])
                    wlevel4.set(i[24])
                    wlevel4_name.set(i[25])
        except IndexError:
            MessageBox.showinfo("ค้นหา","ไม่พบผู้ดูแล : " + name_value,parent = top)
    b = ttk.Button(top,text="ค้นหา",style='font_in.TButton',command= lambda:search_id_up()).place( relx = 0.85, rely = 0.03)
def get_detial_place():
    def set_zero():
        id_room_place.set(room.get())
        name_place.set("")
        level1.set("")
        level1_name.set("")
        level2.set("")
        level2_name.set("")
        level3.set("")
        level3_name.set("")
        level4.set("")
        level4_name.set("")
    set_zero()
    top = Toplevel()
    top.geometry("1280x720")
    top.iconbitmap(photo_)
    top.title("รายละอียดห้อง")
    top.configure(bg=bg_frame)
    x_en = 0.185
    def label(top,x,y,text):
        label = ttk.Label(top,text = text,font=("TH Sarabun New",20,'bold'),background=bg_frame)
        label.place(relwidth = 0.2, relheight = 0.1, relx = x, rely = y)
    #room รหัสห้อง
    label(top,0.04,0.03,"รหัสห้อง :")
    entry_room = ttk.Entry(top,textvariable= room,font=("TH Sarabun New",20,'bold'))
    entry_room.place(relwidth = 0.1, relheight = 0.045, relx = x_en-0.075, rely = 0.05)
    #name ชื่อห้อง
    label(top,0.35,0.03,"ชื่อห้อง :")
    entry_name = ttk.Entry(top,textvariable= name_place,font=("TH Sarabun New",20,'bold'))
    entry_name.place(relwidth = 0.15, relheight = 0.045, relx = x_en+0.25, rely = 0.05)
    #tel เบอร์ติดต่อ
    label(top,0.6,0.03,"เบอร์ติดต่อ :")
    entry_name = ttk.Entry(top,textvariable= tel,font=("TH Sarabun New",20,'bold'))
    entry_name.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.5, rely = 0.05)
    #level4 กอง/สำนัก
    label(top,0.04,0.11,"กอง/สำนัก :")
    entry_level4 = ttk.Entry(top,textvariable= level4,font=("TH Sarabun New",20,'bold'))
    entry_level4.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.05, rely = 0.13)
    #level4_name 
    entry_level4_name = ttk.Entry(top,textvariable= level4_name,font=("TH Sarabun New",20,'bold'))
    entry_level4_name.place(relwidth = 0.14, relheight = 0.045, relx = x_en+0.075, rely = 0.13)
    #level3
    entry_level3 = ttk.Entry(top,textvariable= level3,font=("TH Sarabun New",20,'bold'))
    entry_level3.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.21)
    #level3_name
    entry_level3_name = ttk.Entry(top,textvariable= level3_name,font=("TH Sarabun New",20,'bold'))
    entry_level3_name.place(relwidth = 0.175, relheight = 0.045, relx = x_en-0.025, rely = 0.21)
    #level2
    entry_level2 = ttk.Entry(top,textvariable= level2,font=("TH Sarabun New",20,'bold'))
    entry_level2.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.28)
    #level2_name
    entry_level2_name = ttk.Entry(top,textvariable= level2_name,font=("TH Sarabun New",20,'bold'))
    entry_level2_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en-0.025, rely = 0.28)
    #level1
    entry_level1 = ttk.Entry(top,textvariable= level1,font=("TH Sarabun New",20,'bold'))
    entry_level1.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.35)
    #level1_name
    entry_level1_name = ttk.Entry(top,textvariable= level1_name,font=("TH Sarabun New",20,'bold'))
    entry_level1_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en-0.025, rely = 0.35)

    def search_id_up():
        temp = search_in_db()
        room_value = room.get()
        if(room_value ==""):
            MessageBox.showinfo("ห้อง","กรุณาใส่รหัสห้อง",parent = top)
            return
        try:
            rows = temp.get_db_place(room_value)
            if rows[0]!= NULL:
                for i in rows:
                    name_place.set(i[1])
                    tel.set(i[2])
                    level1.set(i[3])
                    level1_name.set(i[4])
                    level2.set(i[5])
                    level2_name.set(i[6])
                    level3.set(i[7])
                    level3_name.set(i[8])
                    level4.set(i[9])
                    level4_name.set(i[10])
        except IndexError:
            MessageBox.showinfo("อัพเดตสถานะรหัสครุภัณฑ์","ไม่พบรหัสครุภัณฑ์ : " + room_value,parent = top)
    b = ttk.Button(top,text="ค้นหา",style='font_in.TButton',command= lambda:search_id_up()).place( relx = 0.235, rely = 0.03)
def update_owner():
    def set_zero():
        name_full.set("")
        font_name.set("")
        name_font.set("")
        name_last.set("")
        post.set("")
        olevel.set("")
        oroom.set("")
        oroom_name.set("")
        otel.set("")
        olevel1.set("")
        olevel1_name.set("")
        olevel2.set("")
        olevel2_name.set("")
        olevel3.set("")
        olevel3_name.set("")
        olevel4.set("")
        olevel4_name.set("")
        wrooom.set("")
        wroom_name.set("")
        wtel.set("")
        wlevel1.set("")
        wlevel1_name.set("")
        wlevel2.set("")
        wlevel2_name.set("")
        wlevel3.set("")
        wlevel3_name.set("")
        wlevel4.set("")
        wlevel4_name.set("")
    set_zero()
    top = Toplevel()
    top.geometry("1280x720+100+100")
    top.iconbitmap(photo_)
    top.title("อัพเดตผู้ดูแล")
    top.configure(bg=bg_frame)
    x_en = 0.185
    #StringVar()
    font_name_clicked = StringVar()
    post_clicked = StringVar()
    olevel_clicked = StringVar()
    oroom_clicked = StringVar()
    olevel4_clicked = StringVar()
    olevel4_name_clicked = StringVar()
    olevel3_clicked = StringVar()
    olevel3_name_clicked = StringVar()
    olevel2_clicked = StringVar()
    olevel2_name_clicked = StringVar()
    olevel1_clicked = StringVar()
    olevel1_name_clicked = StringVar()
    wroom_clicked = StringVar()
    wlevel4_clicked = StringVar()
    wlevel4_name_clicked = StringVar()
    wlevel3_clicked = StringVar()
    wlevel3_name_clicked = StringVar()
    wlevel2_clicked = StringVar()
    wlevel2_name_clicked = StringVar()
    wlevel1_clicked = StringVar()
    wlevel1_name_clicked = StringVar()
    name_clicked = StringVar()
    def label(top,x,y,text):
        label = ttk.Label(top,text = text,font=("TH Sarabun New",20,'bold'),background=bg_frame)
        label.place(relwidth = 0.20, relx = x, rely = y)
    def set_font_name(e):
        font_name.set("")
        entry_font_name.insert(0,font_name_clicked.get())
    def set_post(e):
        post.set("")
        entry_post.insert(0,post_clicked.get())
    def set_olevel(e):
        olevel.set("")
        entry_olevel.insert(0,olevel_clicked.get())
    def set_oroom(e):
        oroom.set("")
        entry_oroom.insert(0,oroom_clicked.get())
    def set_olevel4(e):
        olevel4.set("")
        entry_olevel4.insert(0,olevel4_clicked.get())
    def set_olevel4_name(e):
        olevel4_name.set("")
        entry_olevel4_name.insert(0,olevel4_name_clicked.get())
    def set_olevel3(e):
        olevel3.set("")
        entry_olevel3.insert(0,olevel3_clicked.get())
    def set_olevel3_name(e):
        olevel3_name.set("")
        entry_olevel3_name.insert(0,olevel3_name_clicked.get())
    def set_olevel2(e):
        olevel2.set("")
        entry_olevel2.insert(0,olevel2_clicked.get())
    def set_olevel2_name(e):
        olevel2_name.set("")
        entry_olevel2_name.insert(0,olevel2_name_clicked.get())
    def set_olevel1(e):
        olevel1.set("")
        entry_olevel1.insert(0,olevel1_clicked.get())
    def set_olevel1_name(e):
        olevel1_name.set("")
        entry_olevel1_name.insert(0,olevel1_name_clicked.get())
    ###########
    def set_wrooom(e):
        wrooom.set("")
        entry_wrooom.insert(0,wroom_clicked.get())
    def set_wlevel4(e):
        wlevel4.set("")
        entry_wlevel4.insert(0,wlevel4_clicked.get())
    def set_wlevel4_name(e):
        wlevel4_name.set("")
        entry_wlevel4_name.insert(0,wlevel4_name_clicked.get())
    def set_wlevel3(e):
        wlevel3.set("")
        entry_wlevel3.insert(0,wlevel3_clicked.get())
    def set_wlevel3_name(e):
        wlevel3_name.set("")
        entry_wlevel3_name.insert(0,wlevel3_name_clicked.get())
    def set_wlevel2(e):
        wlevel2.set("")
        entry_wlevel2.insert(0,wlevel2_clicked.get())
    def set_wlevel2_name(e):
        wlevel2_name.set("")
        entry_wlevel2_name.insert(0,wlevel2_name_clicked.get())
    def set_wlevel1(e):
        wlevel1.set("")
        entry_wlevel1.insert(0,wlevel1_clicked.get())
    def set_wlevel1_name(e):
        wlevel1_name.set("")
        entry_wlevel1_name.insert(0,wlevel1_name_clicked.get())
    def set_name(e):
        name_full.set("")
        entry_name.insert(0,name_clicked.get())
    #font_name คำนำหน้าชื่อ
    label(top,0.04,0.05,"ชื่อ-นามสกุล :")
    entry_font_name = ttk.Entry(top,textvariable= font_name,font=("TH Sarabun New",20,'bold'))
    entry_font_name.place(relwidth = 0.155, relheight = 0.045, relx = x_en-0.05, rely = 0.05)
    font_name_c = ttk.Combobox(top,justify='center',textvariable=font_name_clicked,font=("TH Sarabun New",18), values = font_name_db)
    font_name_c.set(font_name_db[0])
    font_name_c.bind("<<ComboboxSelected>>", set_font_name)
    font_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.115, rely = 0.05)
    #name_owner ชื่อ
    entry_name = ttk.Entry(top,textvariable= name_full ,font=("TH Sarabun New",20,'bold'))
    entry_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.235, rely = 0.05)
    name_c = ttk.Combobox(top,textvariable= name_clicked,font=("TH Sarabun New",18,'bold'),values = name_owner_db)
    name_c.set(name_owner_db[0])
    name_c.bind("<<ComboboxSelected>>", set_name)
    name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.54, rely = 0.05)
    #post ตำแหน่ง
    label(top,0.04,0.11,"ตำแหน่ง :")
    entry_post = ttk.Entry(top,textvariable= post,font=("TH Sarabun New",20,'bold'))
    entry_post.place(relwidth = 0.23, relheight = 0.045, relx = x_en-0.075, rely = 0.11)
    post_c = ttk.Combobox(top,justify='center',textvariable=post_clicked,font=("TH Sarabun New",18), values = post_db)
    post_c.set(post_db[0])
    post_c.bind("<<ComboboxSelected>>", set_post)
    post_c.place(relwidth = 0.135, relheight = 0.045, relx = x_en+0.165, rely = 0.11)
    #olevel ระดับ
    label(top,0.49,0.11,"ระดับ :")
    entry_olevel = ttk.Entry(top,textvariable= olevel,font=("TH Sarabun New",20,'bold'))
    entry_olevel.place(relwidth = 0.15, relheight = 0.045, relx = x_en+0.355, rely = 0.11)
    olevel_c = ttk.Combobox(top,justify='center',textvariable=olevel_clicked,font=("TH Sarabun New",18), values = olevel_db)
    olevel_c.set(olevel_db[0])
    olevel_c.bind("<<ComboboxSelected>>", set_olevel)
    olevel_c.place(relwidth = 0.135, relheight = 0.045, relx = x_en+0.525, rely = 0.11)
    #oroom รหัสห้อง
    label(top,0.04,0.17,"รหัสห้อง :")
    entry_oroom = ttk.Entry(top,textvariable= oroom,font=("TH Sarabun New",20,'bold'))
    entry_oroom.place(relwidth = 0.1, relheight = 0.045, relx = x_en-0.075, rely = 0.17)
    oroom_c = ttk.Combobox(top,textvariable= oroom_clicked,font=("TH Sarabun New",18,'bold'),values = oroom_db)
    oroom_c.set(oroom_db[0])
    oroom_c.bind("<<ComboboxSelected>>", set_oroom)
    oroom_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.03, rely = 0.17)
    #oroom_name ชื่อห้อง
    label(top,0.35,0.17,"ชื่อห้อง :")
    entry_oroom_name = ttk.Entry(top,textvariable= oroom_name,font=("TH Sarabun New",20,'bold'))
    entry_oroom_name.place(relwidth = 0.15, relheight = 0.045, relx = x_en+0.25, rely = 0.17)
    #otel เบอร์ติดต่อ
    label(top,0.6,0.17,"เบอร์ติดต่อ :")
    entry_otel = ttk.Entry(top,textvariable= otel,font=("TH Sarabun New",20,'bold'))
    entry_otel.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.5, rely = 0.17)
    #level4 กอง/สำนัก
    label(top,0.04,0.24,"กอง/สำนัก :")
    entry_olevel4 = ttk.Entry(top,textvariable= olevel4,font=("TH Sarabun New",20,'bold'))
    entry_olevel4.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.05, rely = 0.24)
    olevel4_c = ttk.Combobox(top,justify='center',textvariable=olevel4_clicked,font=("TH Sarabun New",18), values = olevel4_db )
    olevel4_c.set(olevel4_db[0])
    olevel4_c.bind("<<ComboboxSelected>>", set_olevel4)
    olevel4_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.075, rely = 0.24)
    #olevel4_name 
    entry_olevel4_name = ttk.Entry(top,textvariable= olevel4_name,font=("TH Sarabun New",20,'bold'))
    entry_olevel4_name.place(relwidth = 0.25, relheight = 0.045, relx = x_en+0.2, rely = 0.24)
    olevel4_name_c = ttk.Combobox(top,justify='center',textvariable=olevel4_name_clicked,font=("TH Sarabun New",18), values = olevel4_name_db )
    olevel4_name_c.set(olevel4_name_db[0])
    olevel4_name_c.bind("<<ComboboxSelected>>", set_olevel4_name)
    olevel4_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.475, rely = 0.24)
    #olevel3
    entry_olevel3 = ttk.Entry(top,textvariable= olevel3,font=("TH Sarabun New",20,'bold'))
    entry_olevel3.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.30)
    olevel3_c = ttk.Combobox(top,justify='center',textvariable=olevel3_clicked,font=("TH Sarabun New",18), values = olevel3_db )
    olevel3_c.set(olevel3_db[0])
    olevel3_c.bind("<<ComboboxSelected>>", set_olevel3)
    olevel3_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.30)
    #olevel3_name
    entry_olevel3_name = ttk.Entry(top,textvariable= olevel3_name,font=("TH Sarabun New",20,'bold'))
    entry_olevel3_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.1, rely = 0.30)
    olevel3_name_c = ttk.Combobox(top,justify='center',textvariable=olevel3_name_clicked,font=("TH Sarabun New",18), values = olevel3_name_db )
    olevel3_name_c.set(olevel3_name_db[0])
    olevel3_name_c.bind("<<ComboboxSelected>>", set_olevel3_name)
    olevel3_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.415, rely = 0.30)

    #olevel2
    entry_olevel2 = ttk.Entry(top,textvariable= olevel2,font=("TH Sarabun New",20,'bold'))
    entry_olevel2.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.36)
    olevel2_c = ttk.Combobox(top,justify='center',textvariable=olevel2_clicked,font=("TH Sarabun New",18), values = olevel2_db )
    olevel2_c.set(olevel2_db[0])
    olevel2_c.bind("<<ComboboxSelected>>", set_olevel2)
    olevel2_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.36)
    #olevel2_name
    entry_olevel2_name = ttk.Entry(top,textvariable= olevel2_name,font=("TH Sarabun New",20,'bold'))
    entry_olevel2_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.1, rely = 0.36)
    olevel2_name_c = ttk.Combobox(top,justify='center',textvariable=olevel2_name_clicked,font=("TH Sarabun New",18), values = olevel2_name_db )
    olevel2_name_c.set(olevel2_name_db[0])
    olevel2_name_c.bind("<<ComboboxSelected>>", set_olevel2_name)
    olevel2_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.415, rely = 0.36)

    #olevel1
    entry_olevel1 = ttk.Entry(top,textvariable= olevel1,font=("TH Sarabun New",20,'bold'))
    entry_olevel1.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.42)
    olevel1_c = ttk.Combobox(top,justify='center',textvariable=olevel1_clicked,font=("TH Sarabun New",18), values = olevel1_db )
    olevel1_c.set(olevel1_db[0])
    olevel1_c.bind("<<ComboboxSelected>>", set_olevel1)
    olevel1_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.42)
    #olevel1_name
    entry_olevel1_name = ttk.Entry(top,textvariable= olevel1_name,font=("TH Sarabun New",20,'bold'))
    entry_olevel1_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.1, rely = 0.42)
    olevel1_name_c = ttk.Combobox(top,justify='center',textvariable=olevel1_name_clicked,font=("TH Sarabun New",18), values = olevel1_name_db )
    olevel1_name_c.set(olevel1_name_db[0])
    olevel1_name_c.bind("<<ComboboxSelected>>", set_olevel1_name)
    olevel1_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.415, rely = 0.42)
    #หน่วยงานผู้รับผิดชอบครุภัณฑ์
    l1 = Label(top,text="หน่วยงานผู้รับผิดชอบครุภัณฑ์",font=("TH Sarabun New",24,'bold'),background=bg_frame)
    l1.place(relx=0.4,rely=0.48)
    #wrooom รหัสห้อง
    label(top,0.04,0.54,"รหัสห้อง :")
    entry_wrooom = ttk.Entry(top,textvariable= wrooom,font=("TH Sarabun New",20,'bold'))
    entry_wrooom.place(relwidth = 0.1, relheight = 0.045, relx = x_en-0.075, rely = 0.54)
    wrooom_c = ttk.Combobox(top,textvariable= wroom_clicked,font=("TH Sarabun New",18,'bold'),values = wrooom_db)
    wrooom_c.set(wrooom_db[0])
    wrooom_c.bind("<<ComboboxSelected>>", set_wrooom)
    wrooom_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.03, rely = 0.54)
    #wroom_name ชื่อห้อง
    label(top,0.35,0.54,"ชื่อห้อง :")
    entry_oroom_name = ttk.Entry(top,textvariable= wroom_name,font=("TH Sarabun New",20,'bold'))
    entry_oroom_name.place(relwidth = 0.15, relheight = 0.045, relx = x_en+0.25, rely = 0.54)
    #wtel เบอร์ติดต่อ
    label(top,0.6,0.54,"เบอร์ติดต่อ :")
    entry_otel = ttk.Entry(top,textvariable= wtel,font=("TH Sarabun New",20,'bold'))
    entry_otel.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.5, rely = 0.54)
    #wlevel4 กอง/สำนัก
    label(top,0.04,0.60,"กอง/สำนัก :")
    entry_wlevel4 = ttk.Entry(top,textvariable= wlevel4,font=("TH Sarabun New",20,'bold'))
    entry_wlevel4.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.05, rely = 0.60)
    wlevel4_c = ttk.Combobox(top,justify='center',textvariable=wlevel4_clicked,font=("TH Sarabun New",18), values = wlevel4_db )
    wlevel4_c.set(wlevel4_db[0])
    wlevel4_c.bind("<<ComboboxSelected>>", set_wlevel4)
    wlevel4_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.075, rely = 0.60)
    #wlevel4_name 
    entry_wlevel4_name = ttk.Entry(top,textvariable= wlevel4_name,font=("TH Sarabun New",20,'bold'))
    entry_wlevel4_name.place(relwidth = 0.25, relheight = 0.045, relx = x_en+0.2, rely = 0.60)
    wlevel4_name_c = ttk.Combobox(top,justify='center',textvariable=wlevel4_name_clicked,font=("TH Sarabun New",18), values = wlevel4_name_db )
    wlevel4_name_c.set(wlevel4_name_db[0])
    wlevel4_name_c.bind("<<ComboboxSelected>>", set_wlevel4_name)
    wlevel4_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.475, rely = 0.60)
    #wlevel3
    entry_wlevel3 = ttk.Entry(top,textvariable= wlevel3,font=("TH Sarabun New",20,'bold'))
    entry_wlevel3.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.66)
    wlevel3_c = ttk.Combobox(top,justify='center',textvariable=wlevel3_clicked,font=("TH Sarabun New",18), values = wlevel3_db )
    wlevel3_c.set(wlevel3_db[0])
    wlevel3_c.bind("<<ComboboxSelected>>", set_wlevel3)
    wlevel3_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.66)
    #wlevel3_name
    entry_wlevel3_name = ttk.Entry(top,textvariable= wlevel3_name,font=("TH Sarabun New",20,'bold'))
    entry_wlevel3_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.1, rely = 0.66)
    wlevel3_name_c = ttk.Combobox(top,justify='center',textvariable=wlevel3_name_clicked,font=("TH Sarabun New",18), values = wlevel3_name_db )
    wlevel3_name_c.set(olevel3_name_db[0])
    wlevel3_name_c.bind("<<ComboboxSelected>>", set_wlevel3_name)
    wlevel3_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.415, rely = 0.66)

    #wlevel2
    entry_wlevel2 = ttk.Entry(top,textvariable= wlevel2,font=("TH Sarabun New",20,'bold'))
    entry_wlevel2.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.72)
    wlevel2_c = ttk.Combobox(top,justify='center',textvariable=wlevel2_clicked,font=("TH Sarabun New",18), values = wlevel2_db )
    wlevel2_c.set(wlevel2_db[0])
    wlevel2_c.bind("<<ComboboxSelected>>", set_wlevel2)
    wlevel2_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.72)
    #wlevel2_name
    entry_wlevel2_name = ttk.Entry(top,textvariable= wlevel2_name,font=("TH Sarabun New",20,'bold'))
    entry_wlevel2_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.1, rely = 0.72)
    wlevel2_name_c = ttk.Combobox(top,justify='center',textvariable=wlevel2_name_clicked,font=("TH Sarabun New",18), values = wlevel2_name_db )
    wlevel2_name_c.set(wlevel2_name_db[0])
    wlevel2_name_c.bind("<<ComboboxSelected>>", set_wlevel2_name)
    wlevel2_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.415, rely = 0.72)

    #wlevel1
    entry_wlevel1 = ttk.Entry(top,textvariable= wlevel1,font=("TH Sarabun New",20,'bold'))
    entry_wlevel1.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.15, rely = 0.78)
    wlevel1_c = ttk.Combobox(top,justify='center',textvariable=wlevel1_clicked,font=("TH Sarabun New",18), values = wlevel1_db )
    wlevel1_c.set(wlevel1_db[0])
    wlevel1_c.bind("<<ComboboxSelected>>", set_wlevel1)
    wlevel1_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en-0.025, rely = 0.78)
    #wlevel1_name
    entry_wlevel1_name = ttk.Entry(top,textvariable= wlevel1_name,font=("TH Sarabun New",20,'bold'))
    entry_wlevel1_name.place(relwidth = 0.3, relheight = 0.045, relx = x_en+0.1, rely = 0.78)
    wlevel1_name_c = ttk.Combobox(top,justify='center',textvariable=wlevel1_name_clicked,font=("TH Sarabun New",18), values = wlevel1_name_db )
    wlevel1_name_c.set(wlevel1_name_db[0])
    wlevel1_name_c.bind("<<ComboboxSelected>>", set_wlevel1_name)
    wlevel1_name_c.place(relwidth = 0.115, relheight = 0.045, relx = x_en+0.415, rely = 0.78)

    b = ttk.Button(top,text="เพิ่มข้อมูล",style='font_in.TButton',command=lambda:update_data()).place(relwidth = 0.13, relheight = 0.075, relx = x_en+0.65, rely = 0.85)
    search_db = ttk.Button(top,text="ค้นหาจากชื่อ",style='font_in.TButton',command=lambda:search_id_up()).place(relwidth = 0.13, relheight = 0.075, relx = x_en+0.675, rely = 0.03)
    call_in_db_ = database_connector()
    def search_id_up():
        temp = search_in_db()
        name_value = name_full.get()
        if(name_value ==""):
            MessageBox.showinfo("ผู้ดูแล","กรุณาใส่ชื่อผู้ดูแล",parent = top)
            return
        try:
            rows = temp.get_db_owner(name_value)
            if rows[0]!= NULL:
                for i in rows:
                    font_name.set(i[0])
                    name_full.set(i[1])
                    post.set(i[2])
                    olevel.set(i[3])
                    oroom.set(i[4])
                    oroom_name.set(i[5])
                    otel.set(i[6])
                    olevel1.set(i[7])
                    olevel1_name.set(i[8])
                    olevel2.set(i[9])
                    olevel2_name.set(i[10])
                    olevel3.set(i[11])
                    olevel3_name.set(i[12])
                    olevel4.set(i[13])
                    olevel4_name.set(i[14])
                    wrooom.set(i[15])
                    wroom_name.set(i[16])
                    wtel.set(i[17])
                    wlevel1.set(i[18])
                    wlevel1_name.set(i[19])
                    wlevel2.set(i[20])
                    wlevel2_name.set(i[21])
                    wlevel3.set(i[22])
                    wlevel3_name.set(i[23])
                    wlevel4.set(i[24])
                    wlevel4_name.set(i[25])
        except IndexError:
            MessageBox.showinfo("ค้นหา","ไม่พบผู้ดูแล : " + name_value,parent = top)
    def update_data():
        font_name_value = font_name.get()
        name_full_value = name_full.get()
        post_value = post.get()
        olevel_value = olevel.get()
        oroom_value = oroom.get()
        oroom_name_value = oroom_name.get()
        otel_value = otel.get()
        olevel4_value = olevel4.get()
        olevel4_name_value = olevel4_name.get()
        olevel3_value = olevel3.get()
        olevel3_name_value = olevel3_name.get()
        olevel2_value = olevel2.get()
        olevel2_name_value = olevel2_name.get()
        olevel1_value = olevel1.get()
        olevel1_name_value = olevel1_name.get()
        wrooom_value = wrooom.get()
        wroom_name_value = wroom_name.get()
        wtel_value = wtel.get()
        wlevel1_value = wlevel1.get()
        wlevel1_name_value = wlevel1_name.get()
        wlevel2_value = wlevel2.get()
        wlevel2_name_value = wlevel2_name.get()
        wlevel3_value = wlevel3.get()
        wlevel3_name_value = wlevel3_name.get()
        wlevel4_value = wlevel4.get()
        wlevel4_name_value = wlevel4_name.get()
        if(name_full_value==""):
            MessageBox.showinfo("เพิ่มผู้ดูแล","กรุณาใส่ข้อมูล",parent = top)
            return
        try :
            call_in_db_.update_owner(font_name_value,name_full_value,post_value,olevel_value,oroom_value,oroom_name_value,otel_value,olevel1_value,olevel1_name_value,olevel2_value,olevel2_name_value,olevel3_value,olevel3_name_value,olevel4_value,olevel4_name_value,wrooom_value,wroom_name_value,wtel_value,wlevel1_value,wlevel1_name_value,wlevel2_value,wlevel2_name_value,wlevel3_value,wlevel3_name_value,wlevel4_value,wlevel4_name_value)
            set_zero()
            MessageBox.showinfo("เพิ่มผู้ดูแล","เพิ่มข้อมูลสำเร็จ",parent = top)
        except:
            set_zero()
            MessageBox.showinfo("เพิ่มผู้ดูแล","มีข้อมูลนี้อยู่แล้ว",parent = top)
def table_43():
    allcount = table_()
    try:
        list_ = allcount.data43()
    except:
        MessageBox.showerror("Error","ไม่พบ Database",parent = root)
    total_rows = len(list_)
    total_columns = len(list_[0])
    all = []
    def sum_all():
        for i in range(total_columns):
            x=0
            for j in range(total_rows):
                if j>=0 and i>=0:
                    if list_[j][i]=='-':
                        x = x + 0
                    else :
                        x = x + list_[j][i]
            all.append(x)
    t1 = threading.Thread(target=sum_all)
    t1.start()
    top = Toplevel()
    top.iconbitmap(photo_)
    top.geometry("1310x768")
    top.title("ป๊ 43 - 53")
    canvas = Canvas(top)
    scroll_y = Scrollbar(top, orient="vertical", command=canvas.yview)
    frame = Frame(canvas)
    for i in range(total_rows+1):#row
        for j in range(total_columns):#col
                    if j ==0 and i ==0:
                        e = Entry(frame, width=15,
                        font=('TH Sarabun New',16,'bold'),justify='center')
                        e.grid(row=0, column=0)
                        e.insert(END, 'ประเภท')
                    elif j >=1 and i ==0:
                        if i ==0 and j ==1:
                            e = Entry(frame, width=25, fg='Black',
                            font=('TH Sarabun New',16,'bold'),justify='center')
                            e.grid(row=0, column=j)
                            e.insert(END, year_T43[j-1])
                        else:
                            e = Entry(frame, width=5, fg='Black',
                            font=('TH Sarabun New',16,'bold'),justify='center')
                            e.grid(row=0, column=j)
                            e.insert(END, year_T43[j-1])
                    elif j ==0 and i >=1:
                        e = Entry(frame, width=15, fg='Black',
                        font=('TH Sarabun New',16,'bold',),justify='center')
                        e.grid(row=i, column=0)
                        e.insert(0, typeall[i-1])
                    elif j== 1 and i>=1:
                        e = Entry(frame, width=25, fg='white',
                        font=('TH Sarabun New',16,'bold'),justify='center')
                        e.grid(row=i, column=1)
                        e.insert(END, numtype[i-1])
                        e.configure({"background": "#6560FA"})
                    else :
                        e = Entry(frame, width=5, fg='Black',
                        font=('TH Sarabun New',16,'bold'),justify='center')
                        e.grid(row=i, column=j)
                        if j%2 ==0:
                            e.insert(END, list_[i-1][j-2])            
                        else :
                            e.insert(END, list_[i-1][j-2])
                            e.configure({"background": "#D6B2FF"})
                    if j>=2 and i==total_rows:
                        e = Entry(frame, width=5,
                        font=('TH Sarabun New',16,'bold'),justify='center')
                        e.grid(row=total_rows+2, column=j)
                        e.insert(END, all[j-2])
                    elif j==0 and i==total_rows:
                        e = Entry(frame, width=15,
                        font=('TH Sarabun New',16,'bold'),justify='center')
                        e.grid(row=total_rows+2, column=j)
                        e.insert(END, "")
                    elif j==1 and i==total_rows:
                        e = Entry(frame, width=25,
                        font=('TH Sarabun New',16,'bold'),justify='center')
                        e.grid(row=total_rows+2, column=j)
                        e.insert(END, "รวม")
    list_.clear() 
    b = ttk.Button(frame,text = "54-64",width=5,command=table_54)
    b.grid(row=total_rows+3, column=total_columns-1) 
    canvas.create_window(0, 0, anchor='nw', window=frame)
    canvas.update_idletasks()

    canvas.configure(scrollregion=canvas.bbox('all'), 
                    yscrollcommand=scroll_y.set)
    canvas.pack(fill='both', expand=True, side='left')
    scroll_y.pack(fill='y' , side='right')
def table_54():
    allcount = table_()
    try:
        list_ = allcount.data54()
    except:
        MessageBox.showerror("Error","ไม่พบ Database",parent = root)
    total_rows = len(list_)
    total_columns = len(list_[0])
    all = []
    def sum_all():
        for i in range(total_columns):
            x=0
            for j in range(total_rows):
                if j>=0 and i>=0:
                    if list_[j][i]=='-':
                        x = x + 0
                    else :
                        x = x + list_[j][i]
            all.append(x)
    t1 = threading.Thread(target=sum_all)
    t1.start()
    top = Toplevel()
    top.iconbitmap(photo_)
    top.geometry("1310x768")
    top.title("ปี 54 - 64")
    canvas = Canvas(top)
    scroll_y = Scrollbar(top, orient="vertical", command=canvas.yview)
    frame = Frame(canvas)
    for i in range(total_rows+1):#row
        for j in range(total_columns+2):#col
                    if j ==0 and i ==0:
                        e = Entry(frame, width=15,
                        font=('TH Sarabun New',16,'bold'),justify='center')
                        e.grid(row=0, column=0)
                        e.insert(END, 'ประเภท')
                    elif j >=1 and i ==0:
                        if i ==0 and j ==1:
                            e = Entry(frame, width=25, fg='Black',
                            font=('TH Sarabun New',16,'bold'),justify='center')
                            e.grid(row=0, column=j,ipady=0)
                            e.insert(END, year_T54[j-1])
                        else:
                            e = Entry(frame, width=5, fg='Black',
                            font=('TH Sarabun New',16,'bold'),justify='center')
                            e.grid(row=0, column=j)
                            e.insert(END, year_T54[j-1])
                    elif j ==0 and i >=1:
                        e = Entry(frame, width=15, fg='Black',
                        font=('TH Sarabun New',16,'bold'),justify='center')
                        e.grid(row=i, column=0)
                        e.insert(END, typeall[i-1])
                    elif j==1 and i>=1:
                        e = Entry(frame, width=25, fg='white',
                        font=('TH Sarabun New',16,'bold'),justify='center')
                        e.grid(row=i, column=1)
                        e.insert(END, numtype[i-1])
                        e.configure({"background": "#6560FA"})
                    else:
                        e = Entry(frame, width=5, fg='Black',
                        font=('TH Sarabun New',16,'bold'),justify='center')
                        e.grid(row=i, column=j)
                        if j%2 ==0:
                            e.insert(END, list_[i-1][j-2])
                        else :
                            e.insert(END, list_[i-1][j-2])
                            e.configure({"background": "#D6B2FF"})
                    if j>=2 and i==total_rows:
                        e = Entry(frame, width=5,
                        font=('TH Sarabun New',16,'bold'),justify='center')
                        e.grid(row=total_rows+2, column=j)
                        e.insert(END, all[j-2])
                    elif j==0 and i==total_rows:
                        e = Entry(frame, width=15,
                        font=('TH Sarabun New',16,'bold'),justify='center')
                        e.grid(row=total_rows+2, column=j)
                        e.insert(END, "")
                    elif j==1 and i==total_rows:
                        e = Entry(frame, width=25,
                        font=('TH Sarabun New',16,'bold'),justify='center')
                        e.grid(row=total_rows+2, column=j)
                        e.insert(END, "รวม")
    list_.clear()
    b = ttk.Button(frame,text = "43-53",width=5,command= table_43)
    b.grid(row=total_rows+3, column=total_columns+1)
    canvas.create_window(0, 0, anchor='nw', window=frame)
    canvas.update_idletasks()

    canvas.configure(scrollregion=canvas.bbox('all'), 
                    yscrollcommand=scroll_y.set)
    canvas.pack(fill='both', expand=True, side='left')
    scroll_y.pack(fill='y' , side='right')
def show_place():
    top = Toplevel()
    top.geometry("1280x720")
    top.iconbitmap(photo_)
    top.title("ห้องทั้งหมด")
    top.configure(bg=bg_frame)
    global l1
    l1 = Label(top)
    # Create a Treeview Frame
    frame = ttk.Frame(top)
    frame.pack(pady=10,fill=BOTH,expand=TRUE)
    frame.place(relwidth = 0.96, relheight = 0.75, relx = 0.03, rely = 0.1)
    # Create a Treeview Scrollbar
    tree_scroll1 = ttk.Scrollbar(frame)
    tree_scroll1.pack(side=RIGHT, fill=Y)
    # Create The Treeview
    my_tree_in = ttk.Treeview(frame, style="mystyle.Treeview",height=20,yscrollcommand=tree_scroll1.set, selectmode="extended",)
    my_tree_in.pack(fill=BOTH,expand=TRUE)
    # Configure the Scrollbar
    tree_scroll1.config(command=my_tree_in.yview)
    # Define Our Columns
    my_tree_in['columns'] = ("1", "2", "3", "4", "5")
    # Format Our Columns
    my_tree_in.column("#0", width=0, stretch=NO)
    my_tree_in.column("1", anchor=W, width=70)
    my_tree_in.column("2", anchor=W, width=150)
    my_tree_in.column("3", anchor=CENTER, width=70)
    my_tree_in.column("4", anchor=CENTER, width=100)
    my_tree_in.column("5", anchor=CENTER, width=150)
    # Create Headings
    my_tree_in.heading("#0", text="", anchor=W)
    my_tree_in.heading("1", text="รหัสห้อง", anchor=W)
    my_tree_in.heading("2", text="ชื่อห้อง", anchor=W)
    my_tree_in.heading("3", text="เบอร์", anchor=CENTER)
    my_tree_in.heading("4", text="กอง/สำนัก", anchor=CENTER)
    my_tree_in.heading("5", text="", anchor=CENTER)
    # Create Striped Row Tags
    my_tree_in.tag_configure('oddrow', background="white")
    my_tree_in.tag_configure('evenrow', background="lightblue")
    def clear_all_in():
        for item in my_tree_in.get_children():
                    my_tree_in.delete(item)
    def search1():
        global l1
        l1.destroy()
        clear_all_in()
        record = []
        global count
        temp = search_in_db()
        records = temp.show_place()
        count = 0
        len_records = len(records)
        for record in records:
            if count % 2 == 0:
                my_tree_in.insert(parent='', index='end', iid=count, text='', values=(record[0], record[1], record[2],record[9], record[10]), tags=('evenrow',))
            else :
                my_tree_in.insert(parent='', index='end', iid=count, text='', values=(record[0], record[1], record[2], record[9], record[10]), tags=('oddrow',))
            count += 1
        l1 = Label(top,text=len_records,font=("TH Sarabun New",40,'bold'),background=bg_frame)
        l1.place(relheight=0.05,relwidth=0.075,relx=0.9,rely = 0.03)
    search1()
    b = ttk.Button(top,text="รายละเอียดห้อง",style='font_in.TButton',command=lambda:get_detial_place()).place(relwidth = 0.13, relheight = 0.075, relx = 0.35, rely = 0.9)
    b1 = ttk.Button(top,text="เพิ่มห้อง",style='font_in.TButton',command=lambda:insert_database_place()).place(relwidth = 0.13, relheight = 0.075, relx = 0.5, rely = 0.9)
    # b2 = ttk.Button(top,text="อัพเดตผู้ดูแล",style='font_in.TButton',command=lambda:update_owner()).place(relwidth = 0.13, relheight = 0.075, relx = 0.65, rely = 0.9)
    b3 = ttk.Button(top,text="ลบห้อง",style='font_in.TButton',command=lambda:delete_place()).place(relwidth = 0.13, relheight = 0.075, relx = 0.8, rely = 0.9)
def show_history():
    top = Toplevel()
    top.geometry("1280x720")
    top.iconbitmap(photo_)
    top.title("ประวัติ")
    top.configure(bg=bg_frame)
    global l1
    l1 = Label(top)
    # Create a Treeview Frame
    frame = ttk.Frame(top)
    frame.pack(pady=10,fill=BOTH,expand=TRUE)
    frame.place(relwidth = 0.96, relheight = 0.75, relx = 0.03, rely = 0.1)
    # Create a Treeview Scrollbar
    tree_scroll1 = ttk.Scrollbar(frame)
    tree_scroll1.pack(side=RIGHT, fill=Y)
    # Create The Treeview
    my_tree_in = ttk.Treeview(frame, style="mystyle.Treeview",height=20,yscrollcommand=tree_scroll1.set, selectmode="extended",)
    my_tree_in.pack(fill=BOTH,expand=TRUE)
    # Configure the Scrollbar
    tree_scroll1.config(command=my_tree_in.yview)
    # Define Our Columns
    my_tree_in['columns'] = ("1", "2", "3", "4", "5")
    # Format Our Columns
    my_tree_in.column("#0", width=0, stretch=NO)
    my_tree_in.column("1", anchor=W, width=130)
    my_tree_in.column("2", anchor=W, width=100)
    my_tree_in.column("3", anchor=CENTER, width=240)
    my_tree_in.column("4", anchor=CENTER, width=70)
    my_tree_in.column("5", anchor=CENTER, width=100)
    # Create Headings
    my_tree_in.heading("#0", text="", anchor=W)
    my_tree_in.heading("1", text="รหัสครุภัณฑ์", anchor=W)
    my_tree_in.heading("2", text="เวลา", anchor=W)
    my_tree_in.heading("3", text="ส.เก่า", anchor=CENTER)
    my_tree_in.heading("4", text="ส.ใหม่", anchor=CENTER)
    my_tree_in.heading("5", text="หมายเหตุ", anchor=CENTER)
    # Create Striped Row Tags
    my_tree_in.tag_configure('oddrow', background="white")
    my_tree_in.tag_configure('evenrow', background="lightblue")
    def clear_all_in():
        for item in my_tree_in.get_children():
                    my_tree_in.delete(item)
    def search_():
        global l1
        l1.destroy()
        clear_all_in()
        record = []
        global count
        temp = search_in_db()
        records = temp.show_history()
        count = 0
        len_records = len(records)
        for record in records:
            if count % 2 == 0:
                my_tree_in.insert(parent='', index='end', iid=count, text='', values=(record[0], record[1], record[2],record[3], record[4]), tags=('evenrow',))
            else :
                my_tree_in.insert(parent='', index='end', iid=count, text='', values=(record[0], record[1], record[2], record[3], record[4]), tags=('oddrow',))
            count += 1
        l1 = Label(top,text=len_records,font=("TH Sarabun New",40,'bold'),background=bg_frame)
        l1.place(relheight=0.05,relwidth=0.075,relx=0.9,rely = 0.03)
    def search_box():
        clear_all_in()
        temp = search_in_db()
        records = temp.three_(s_entry_in.get())
        len_records = len(records)
        count = 0
        for record in records:
            if count % 2 == 0:
                my_tree_in.insert(parent='', index='end', iid=count, text='', values=(record[0], record[1], record[2],record[3], record[4]), tags=('evenrow',))
            else :
                my_tree_in.insert(parent='', index='end', iid=count, text='', values=(record[0], record[1], record[2], record[3], record[4]), tags=('oddrow',))
            count += 1
        l1 = Label(top,text=len_records,font=("TH Sarabun New",40,'bold'),background=bg_frame)
        l1.place(relheight=0.05,relwidth=0.075,relx=0.9,rely = 0.03)
    search_entry = ttk.Entry(top,textvariable = s_entry_in).place(relwidth = 0.1, relheight = 0.032, relx = 0.75, rely = 0.04)
    search_button = ttk.Button(top,image=photoImg,command=search_box).place(relwidth = 0.020, relheight = 0.033, relx = 0.851, rely = 0.04)
    search_()
def show_owner():
    top = Toplevel()
    top.geometry("1280x720")
    top.iconbitmap(photo_)
    top.title("ผู้ดูแลทั้งหมด")
    top.configure(bg=bg_frame)
    global l1
    l1 = Label(top)
    # Create a Treeview Frame
    frame = ttk.Frame(top)
    frame.pack(pady=10,fill=BOTH,expand=TRUE)
    frame.place(relwidth = 0.96, relheight = 0.75, relx = 0.03, rely = 0.1)
    # Create a Treeview Scrollbar
    tree_scroll1 = ttk.Scrollbar(frame)
    tree_scroll1.pack(side=RIGHT, fill=Y)
    # Create The Treeview
    my_tree_in = ttk.Treeview(frame, style="mystyle.Treeview",height=20,yscrollcommand=tree_scroll1.set, selectmode="extended",)
    my_tree_in.pack(fill=BOTH,expand=TRUE)
    # Configure the Scrollbar
    tree_scroll1.config(command=my_tree_in.yview)
    # Define Our Columns
    my_tree_in['columns'] = ("1", "2", "3", "4", "5", "6","7")
    # Format Our Columns
    my_tree_in.column("#0", width=0, stretch=NO)
    my_tree_in.column("1", anchor=W, width=130)
    my_tree_in.column("2", anchor=W, width=100)
    my_tree_in.column("3", anchor=CENTER, width=240)
    my_tree_in.column("4", anchor=CENTER, width=70)
    my_tree_in.column("5", anchor=CENTER, width=100)
    my_tree_in.column("6", anchor=CENTER, width=240)
    my_tree_in.column("7", anchor=CENTER, width=70)
    # Create Headings
    my_tree_in.heading("#0", text="", anchor=W)
    my_tree_in.heading("1", text="ผู้ดูแล", anchor=W)
    my_tree_in.heading("2", text="ห้อง(เจ้าหน้าที่)", anchor=W)
    my_tree_in.heading("3", text="ชื่อห้อง", anchor=CENTER)
    my_tree_in.heading("4", text="เบอร์", anchor=CENTER)
    my_tree_in.heading("5", text="ห้อง(หน่วยงาน)", anchor=CENTER)
    my_tree_in.heading("6", text="ชื่อห้อง", anchor=CENTER)
    my_tree_in.heading("7", text="เบอร์", anchor=CENTER)
    # Create Striped Row Tags
    my_tree_in.tag_configure('oddrow', background="white")
    my_tree_in.tag_configure('evenrow', background="lightblue")
    def clear_all_in():
        for item in my_tree_in.get_children():
                    my_tree_in.delete(item)
    def search_():
        global l1
        l1.destroy()
        clear_all_in()
        record = []
        global count
        s_entry.set("")
        temp = search_in_db()
        records = temp.show_owner()
        count = 0
        len_records = len(records)
        for record in records:
            if count % 2 == 0:
                my_tree_in.insert(parent='', index='end', iid=count, text='', values=(record[1], record[4], record[5],record[6], record[15], record[16], record[17]), tags=('evenrow',))
            else :
                my_tree_in.insert(parent='', index='end', iid=count, text='', values=(record[1], record[4], record[5], record[6], record[15], record[16], record[17]), tags=('oddrow',))
            count += 1
        l1 = Label(top,text=len_records,font=("TH Sarabun New",40,'bold'),background=bg_frame)
        l1.place(relheight=0.05,relwidth=0.075,relx=0.9,rely = 0.03)
    search_()
    b = ttk.Button(top,text="รายละเอียดห้อง",style='font_in.TButton',command=lambda:get_detail_owner()).place(relwidth = 0.13, relheight = 0.075, relx = 0.35, rely = 0.9)
    b1 = ttk.Button(top,text="เพิ่มผู้ดูแล",style='font_in.TButton',command=lambda:insert_database_owner()).place(relwidth = 0.13, relheight = 0.075, relx = 0.5, rely = 0.9)
    b2 = ttk.Button(top,text="อัพเดตผู้ดูแล",style='font_in.TButton',command=lambda:update_owner()).place(relwidth = 0.13, relheight = 0.075, relx = 0.65, rely = 0.9)
    b3 = ttk.Button(top,text="ลบผู้ดูแล",style='font_in.TButton',command=lambda:delete_owner()).place(relwidth = 0.13, relheight = 0.075, relx = 0.8, rely = 0.9)
def show_destroy():
    top = Toplevel()
    top.geometry("1280x720")
    top.iconbitmap(photo_)
    top.title("ยุบสภาพ")
    top.configure(bg=bg_frame)
    global l1
    l1 = Label(top)
    # Create a Treeview Frame
    frame = ttk.Frame(top)
    frame.pack(pady=10,fill=BOTH,expand=TRUE)
    frame.place(relwidth = 0.96, relheight = 0.75, relx = 0.03, rely = 0.1)
    # Create a Treeview Scrollbar
    tree_scroll1 = ttk.Scrollbar(frame)
    tree_scroll1.pack(side=RIGHT, fill=Y)
    # Create The Treeview
    my_tree_in = ttk.Treeview(frame, style="mystyle.Treeview",height=20,yscrollcommand=tree_scroll1.set, selectmode="extended",)
    my_tree_in.pack(fill=BOTH,expand=TRUE)
    # Configure the Scrollbar
    tree_scroll1.config(command=my_tree_in.yview)
    # Define Our Columns
    my_tree_in['columns'] = ("1", "2", "3", "4", "5","6")
    # Format Our Columns
    my_tree_in.column("#0", width=0, stretch=NO)
    my_tree_in.column("1", anchor=W, width=130)
    my_tree_in.column("2", anchor=W, width=100)
    my_tree_in.column("3", anchor=CENTER, width=100)
    my_tree_in.column("4", anchor=CENTER, width=70)
    my_tree_in.column("5", anchor=CENTER, width=100)
    my_tree_in.column("6", anchor=CENTER, width=100)
    # Create Headings
    my_tree_in.heading("#0", text="", anchor=W)
    my_tree_in.heading("1", text="รหัสครุภัณฑ์", anchor=W)
    my_tree_in.heading("2", text="TYPE", anchor=W)
    my_tree_in.heading("3", text="สถานะ", anchor=CENTER)
    my_tree_in.heading("4", text="ปี", anchor=CENTER)
    my_tree_in.heading("5", text="ลำดับในปี", anchor=CENTER)
    my_tree_in.heading("6", text="ลำดับในประเภท", anchor=CENTER)
    # Create Striped Row Tags
    my_tree_in.tag_configure('oddrow', background="white")
    my_tree_in.tag_configure('evenrow', background="lightblue")
    def clear_all_in():
        for item in my_tree_in.get_children():
                    my_tree_in.delete(item)
    def search_():
        global l1
        l1.destroy()
        clear_all_in()
        record = []
        global count
        s_entry.set("")
        temp = search_in_db()
        records = temp.show_destroy()
        count = 0
        len_records = len(records)
        for record in records:
            if count % 2 == 0:
                my_tree_in.insert(parent='', index='end', iid=count, text='', values=(record[0], record[1], record[2],record[3], record[4], record[5]), tags=('evenrow',))
            else :
                my_tree_in.insert(parent='', index='end', iid=count, text='', values=(record[0], record[1], record[2], record[3], record[4], record[5]), tags=('oddrow',))
            count += 1
        l1 = Label(top,text=len_records,font=("TH Sarabun New",40,'bold'),background=bg_frame)
        l1.place(relheight=0.05,relwidth=0.075,relx=0.9,rely = 0.03)
    search_()
b1 = bttn(0.015,0.28,"เพิ่มรหัสครุภัณฑ์",insert_database_item)
b2 = bttn(0.015,0.36,"อัพเดตสถานะครุภัณฑ์",get_detail)
b3 = bttn(0.015,0.44,"ลบข้อมูลครุภัณฑ์",delete_database)
b4 = bttn(0.015,0.52,"ปีงบประมาณ 43-53",table_43)
b5 = bttn(0.015,0.60,"ปีงบประมาณ 54-64",table_54)
b6 = bttn(0.015,0.68,"รายละเอียดรหัสครุภัณฑ์",get_detail_more)
b7 = bttn(0.015,0.76,"ห้อง",show_place)
b8 = bttn(0.015,0.84,"ผู้ดูแล",show_owner)
b9 = bttn(0.015,0.92,"ประวัติ",show_history)
img = Image.open(os.path.join(full_dir,image_path,'search_icon.png'))
img = img.resize((13,13))
photoImg =  ImageTk.PhotoImage(img)
l = Label(root)
def search_box():
    search_entry = ttk.Entry(root,textvariable = s_entry).place(relwidth = 0.1, relheight = 0.027, relx = 0.85, rely = 0.181)
    search_button = ttk.Button(root,image=photoImg,command=search_box_in_db)
    # search_button.bind("<key>",search_box_in_db)
    search_button.place(relwidth = 0.015, relheight = 0.026, relx = 0.951, rely = 0.181)
def search_box_in_db():
    global l ,len_records
    clear_all()
    l.destroy()
    year_com.set("ปีทั้งหมด")
    namet_com.set("ประเภททั้งหมด")
    status_com.set("ส.ใช้งานปัจจุบัน")
    temp = search_in_db()
    records = temp.three(s_entry.get())
    len_records = len(records)
    count = 0
    for record in records:
        if count % 2 == 0:
            my_tree.insert(parent='', index='end', iid=count, text='', values=(record[0], record[14], record[16], record[17], record[18], record[19], record[20]), tags=('evenrow',))
        else :
            my_tree.insert(parent='', index='end', iid=count, text='', values=(record[0], record[14], record[16], record[17], record[18], record[19], record[20]), tags=('oddrow',))
        count += 1
    l = Label(root,text=len_records,font=("TH Sarabun New",40,'bold'),background=bg_frame)
    l.place(relheight=0.05,relwidth=0.075,relx=0.9,rely = 0.085)
def search1(e):
    global l
    l.destroy()
    clear_all()
    record = []
    global count
    year_c = clicked_year.get()
    status_c = clicked_status.get()
    type_c = clicked_type.get()
    s_entry.set("")
    if(type_c=="ประเภททั้งหมด" and status_c == "ส.ใช้งานปัจจุบัน"and year_c == "ปีทั้งหมด"):
        temp = search_in_db()
        records = temp.one()
    else:
        temp = search_in_db()
        records = temp.two(status_c,year_c,type_c)
    count = 0
    len_records = len(records)
    for record in records:
        if count % 2 == 0:
            my_tree.insert(parent='', index='end', iid=count, text='', values=(record[0], record[14], record[16], record[17], record[18], record[19], record[20]), tags=('evenrow',))
        else :
            my_tree.insert(parent='', index='end', iid=count, text='', values=(record[0], record[14], record[16], record[17], record[18], record[19], record[20]), tags=('oddrow',))
        count += 1
    l = Label(root,text=len_records,font=("TH Sarabun New",40,'bold'),background=bg_frame)
    l.place(relheight=0.05,relwidth=0.075,relx=0.9,rely = 0.085)
def resize(e):
    if  e.width >=1600:
        b1.config(style='font_re.TButton')
        b2.config(style='font_re.TButton')
        b3.config(style='font_re.TButton')
        b4.config(style='font_re.TButton')
        b5.config(style='font_re.TButton')
        b6.config(style='font_re.TButton')
    elif e.width < 1600:
        b1.config(style='font_in.TButton')
        b2.config(style='font_in.TButton')
        b3.config(style='font_in.TButton')
        b4.config(style='font_in.TButton')
        b5.config(style='font_in.TButton')
        b6.config(style='font_in.TButton')
ti = Label(root,text="",font=("ariel",12,'bold'))
ti.place(relx=0.85,rely = 0.005)
t = Label(root,text='ข้อมูลครุภัณฑ์',font=("TH Sarabun New italic",46,'bold'))
t.config(bg=bg_frame)
t.place(relx = 0.1, rely = 0.001)
t = ttk.Label(root,text='กองยุทธศาสตร์และงบประมาณ  ฝ่ายบริหารงานทั่วไป งานเทคโนโลยีสารสนเทศ',font=("TH Sarabun New italic",24,'bold'))
t.config(background=bg_frame)
t.place(relx = 0.1, rely = 0.09)

t1 = Label(root,image=photo_01)
t1.config(bg=bg_frame)
t1.place(relx = 0.01, rely = 0)
frame01 = ttk.Frame(root, width=1255, height=60, style='top.TFrame').place(relwidth = 0.98, relheight = 0.09, relx = 0.01, rely = 0.15)
# Create a Treeview Frame
tree_frame = ttk.Frame(root)
tree_frame.pack(pady=10,fill=BOTH,expand=TRUE)
tree_frame.place(relwidth = 0.825, relheight = 0.65, relx = 0.175, rely = 0.3)
# Create a Treeview Scrollbar
tree_scroll = ttk.Scrollbar(tree_frame)
tree_scroll.pack(side=RIGHT, fill=Y)
# Create The Treeview
my_tree = ttk.Treeview(tree_frame, style="mystyle.Treeview",height=20,yscrollcommand=tree_scroll.set, selectmode="extended",)
my_tree.pack(fill=BOTH,expand=TRUE)
# Configure the Scrollbar
tree_scroll.config(command=my_tree.yview)
# Define Our Columns
my_tree['columns'] = ("id", "type", "status1", "status2", "status3", "status4","status5")
# Format Our Columns
my_tree.column("#0", width=0, stretch=NO)
my_tree.column("id", anchor=W, width=80)
my_tree.column("type", anchor=W, width=90)
my_tree.column("status1", anchor=CENTER, width=110)
my_tree.column("status2", anchor=CENTER, width=115)
my_tree.column("status3", anchor=CENTER, width=95)
my_tree.column("status4", anchor=CENTER, width=115)
my_tree.column("status5", anchor=CENTER, width=140)
# Create Headings
my_tree.heading("#0", text="", anchor=W)
my_tree.heading("id", text="รหัสครุภัณฑ์", anchor=W)
my_tree.heading("type", text="ประเภทย่อย-อ-", anchor=W)
my_tree.heading("status1", text="ส.พัสดุปัจจุบัน", anchor=CENTER)
my_tree.heading("status2", text="ส.ความรับผิดชอบ", anchor=CENTER)
my_tree.heading("status3", text="ส.ใช้งานปัจจุบัน", anchor=CENTER)
my_tree.heading("status4", text="ส.บำรุงรักษาล่าสุด", anchor=CENTER)
my_tree.heading("status5", text="ส.การตรวจสภาพ",anchor=CENTER)

# Create Striped Row Tags
my_tree.tag_configure('oddrow', background="white")
my_tree.tag_configure('evenrow', background="lightblue")

def clear_all():
	for item in my_tree.get_children():
    			my_tree.delete(item)

clicked_year = StringVar()
year_com = ttk.Combobox(frame01,justify='center',textvariable=clicked_year,font=("TH Sarabun New",20,'bold'),values = year_, )
year_com.config(style='top.TButton')
year_com.set("ปีทั้งหมด")
year_com.place(relwidth = 0.1, relheight = 0.035, relx = 0.05, rely = 0.181)
year_com.bind("<<ComboboxSelected>>", search1)

clicked_type = StringVar()
namet_com = ttk.Combobox(frame01,justify='center',textvariable=clicked_type,font=("TH Sarabun New",20,'bold'),values = namet_,)
namet_com.config(style='top.TButton')
namet_com.set("ประเภททั้งหมด")
namet_com.place(relwidth = 0.1, relheight = 0.035, relx = 0.17, rely = 0.181)
namet_com.bind("<<ComboboxSelected>>", search1)

clicked_status = StringVar()
status_com = ttk.Combobox(frame01,justify='center',textvariable=clicked_status,font=("TH Sarabun New",20,'bold'),values = status3_dp,)
status_com.config(style='top.TButton')
status_com.set(status3_dp[0])
status_com.place(relwidth = 0.1, relheight = 0.035, relx = 0.29, rely = 0.181)
status_com.bind("<<ComboboxSelected>>", search1)
my_tree.bind("<ButtonRelease-1>")
try: 
    threading.Thread(target=search1(1)).start()
    search_box()
except :
    MessageBox.showerror("Error","ไม่พบ Database",parent = root)
time_()
root.bind('<Configure>',resize)
root.mainloop()